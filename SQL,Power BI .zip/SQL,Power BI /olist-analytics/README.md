# Olist marketplace performance review

**SQL + Power BI business analysis of 99,441 Brazilian e-commerce orders.**

A marketplace with a 4.16 average rating, an 8.1% late-delivery rate, and a 3.0%
repeat rate. This project works out which of those three numbers causes the
others, and what it would cost to change them.

All aggregation is done in SQL. Python orchestrates and renders; it does no
analysis. Nine raw CSVs become eight staging views, a six-table star schema, and
twenty-three analysis queries, ending in three recommendations sized in reais.

**[→ The dashboard](output/dashboard/index.html)** — four pages, self-contained HTML,
no build step and no external dependencies.

GitHub displays `.html` as source rather than rendering it, so to actually view it:
clone and open the file, or enable **GitHub Pages** on this repo (Settings → Pages →
deploy from `main`, root) and the same file serves at
`https://<user>.github.io/<repo>/output/dashboard/index.html`.

Run on the real Kaggle dataset: 99,441 orders placed between 2016-09-04 and
2018-10-17, R$15.4M of delivered GMV, 2,970 active sellers.

---

## The findings

**1. Olist has a contractual shipping deadline and does not enforce it.**

Every order line carries a `shipping_limit_date`. **8,724 delivered orders — 9.0%
of the platform — shipped after it.** Those orders are late **24.4%** of the time
against **6.5%**, and score **3.70** against **4.20**.

The mechanism is visible rather than inferred. Deadline-missing orders sit in
seller handover for **9.2 days** against **2.1**, while carrier transit is
effectively identical (9.8 vs 9.2 days). The seller's delay is not a symptom of a
slow lane — it *is* the delay, passed straight through to the customer.

And the damage scales monotonically with the overshoot, which is the strongest
causal evidence observational data can offer:

| Days past deadline | Orders | Late rate | Avg review |
|---|---|---|---|
| 1 day | 5,322 | 15.0% | 3.92 |
| 2–3 days | 1,129 | 23.3% | 3.77 |
| 4–7 days | 1,368 | 33.6% | 3.52 |
| 8–14 days | 584 | 59.6% | 2.93 |
| 15+ days | 321 | 80.7% | 1.99 |

It is also concentrated: the worst two seller deciles are **160 accounts causing
46.2%** of every deadline miss on the platform — 4,032 of 8,724 orders.

That figure is counted distinctly in `12_rec1_shipping_deadline.sql` rather than
by adding the two decile shares, because a few orders are shipped by a decile-9
*and* a decile-10 seller and would otherwise be counted twice.
`20_deadline_by_seller.sql` also returns the ranked-population share (54.4%),
which is the larger and more flattering of the two bases and is not the one quoted
here.

**2. Lateness is a cliff, not a slope.**

Landing 15+ days early scores 4.32. Landing exactly on the promised day scores
4.03 — a fortnight of extra speed is worth about three-tenths of a star. Missing
by **one to three days** scores 3.29, and the detractor rate goes from 12.4% to
**32.1%**, peaking at **80.2%** in the 8-14 day bucket.

Customers do not experience "twelve days". They experience "later than you said".

**3. Quoting later dates would work — and is still the wrong move.**

The obvious reading of finding 2 is to pad the promise and stop missing it. The
honest answer is that this works mechanically, which is exactly why it needs
arguing against rather than dismissing.

| Extra days quoted | Late orders rescued | Late rate after | Avg promise becomes |
|---|---|---|---|
| +1 | 2,117 (27%) | 5.92% | 25.4 d |
| +3 | 3,162 (40%) | 4.83% | 27.4 d |
| +7 | 4,964 (63%) | 2.97% | 31.4 d |
| +14 | 6,442 (82%) | 1.43% | 38.4 d |

Three reasons it is still the wrong headline move:

- **The promise is already padded.** 24.4 days quoted against 12.5 actual — 11.9
  days of slack — and **36.3% of orders already arrive more than a fortnight
  early**. Halving the late rate means quoting around a month.
- **Finding 2 says earliness buys nothing.** Arriving 15+ days early scores 4.32
  against 4.03 for landing on the day. So the padding has no upside to offset the
  worse offer at the point of sale.
- **It changes the metric, not the service.** The customer waits exactly as long.
  Carrier transit on a late order averages **25.7 days** against 7.8, with a p99
  of 84 days and a maximum of 205. A padded date does not rescue that customer;
  it only stops the platform from having promised better.

Across states lateness tracks slowness rather than thin padding, though the
strength depends on the basis: r = **+0.28** unweighted across all 27 states,
**+0.78** order-weighted, **+0.79** across the 22 states with 250+ orders. All
three bases are returned by `21_lateness_correlation.sql` precisely because they
disagree; the sign is what the argument rests on, not the magnitude.

The reasonable version of this idea is a **one-day** pad — 27% of lateness for one
day of quoted time is a real trade — filed as a cheap palliative alongside
recommendation 1, not instead of it.

**4. A sixth of everything shipped is freight-toxic.**

**18,527 units — 16.8%** of all units — carry freight worth more than half the
item's own price. The average unit in that tail is **R$30 of product carrying
R$22 of shipping**, a 74% surcharge. **85.0%** of those orders are single-item
baskets, which is why the freight lands so hard: there is nothing to spread it
over. The tail is 4.2% of revenue but 18.7% of all freight charged.

Behind it sits a supply-geography problem. **73.7% of active sellers are in the
Southeast**; the Northeast takes 9.4% of demand with 1.8% of supply, and the North
takes 1.9% with 0.1%.

**5. Retention is broken at the root — and this is the most important negative
result in the analysis.**

**3.0% of customers ever order twice.** A five-star first order produces a 2.10%
six-month repeat rate; a one-star first order produces 1.66%. The direction is
right, but the forward-GMV gap attached to a detractor is **R$0.35**.

So no customer-experience fix here can be justified by retention revenue. The
money is not there to recover. Such fixes have to be justified by what they cost
and what they prevent — which is exactly how recommendation 1 is argued below.

---

## The recommendations

| # | Move | Annual impact | Cost |
|---|---|---|---|
| 1 | Enforce the shipping deadline on the worst 160 seller accounts | Late rate **8.1% → 7.5%**; **455** fewer late deliveries, **302** fewer detractor reviews | 160 account conversations |
| 2 | Free-shipping threshold on the freight-toxic tail | **R$61.8K** incremental item revenue (R$30.9K–R$92.7K) | One merchandising quarter |
| 3 | Recruit sellers into the Northeast | **R$89.6K** of shipping cost removed; 9.7–12.2 days faster | Twelve months, supply-side |

**Central case: R$151,554 a year, about 1.3% of trailing-twelve-month GMV.**

Full reasoning, sensitivity ranges and assumptions are on page 4 of the dashboard.

### On the honesty of these numbers

**Recommendation 1's revenue figure is R$106 a year, and it is reported as R$106.**
Inflating it would have been easy — pick a plausible conversion elasticity,
multiply by GMV, produce a six-figure number nobody can check. The dataset has no
conversion events, so that number would be fiction.

What the data does support is that recommendation 1 removes 455 late deliveries a
year through 160 account conversations, using an enforcement mechanism that
already exists in every seller contract and is currently unused. The ceiling — every
deadline miss on the platform fixed — is 1,201 late deliveries and 797 detractor
reviews, taking the late rate to 6.5%. A near-infinite return on a near-zero cost
is a better argument than a fabricated large one, and it survives the first hard
question in a review.

**Recommendation 3 carries a caveat stated on the page: freight in this dataset is
paid by the customer, not by Olist.** That R$89.6K is money taken out of customers'
baskets in the worst-served regions. It is a price cut, not margin. The revenue
case runs through conversion, which this dataset cannot measure, so no revenue
figure is claimed for it.

### What changed when the real data arrived

The pipeline was built and tested against a generated stand-in calibrated to the
real dataset's published aggregates. When the Kaggle CSVs were loaded, every query
ran unchanged — but one finding did not survive, and it is worth recording why.

The stand-in produced a striking pattern: the fastest-served states were also the
latest, implying the promise was mis-calibrated rather than the network being slow.
On the real data that pattern **inverts**: slower states are later, as common sense
would suggest (r = +0.28 to +0.79 depending on basis — see finding 3). The paradox was an artefact of how the
stand-in generated promise dates, not a property of Olist.

The recommendation resting on it was deleted and replaced with the shipping-deadline
finding, which is stronger, is supported by a monotone dose-response, and targets a
mechanism the platform already owns. Findings 2, 4 and 5 held on real data; finding
5 got starker (the detractor gap fell from R$3.56 to R$0.35).

The general lesson is in the repo on purpose: a synthetic fixture is good for
proving that a pipeline runs, and worthless as evidence about the world.

---

## Running it

```bash
pip install -r requirements.txt          # duckdb, pandas

# The real data: nine CSVs from Kaggle, unzipped into data/raw/
python scripts/build_db.py
python scripts/run_analysis.py       # → output/tables/*.csv + output/dashboard/index.html
python scripts/export_marts.py       # → output/marts/*.csv, for Power BI

# No Kaggle account? A calibrated stand-in with the same schema:
python scripts/make_sample_data.py --out data/sample
python scripts/build_db.py --raw data/sample
```

`build_db.py` prints a data-quality report on every run — row counts, orphaned
records, the payment-versus-item reconciliation — so a bad load is visible
immediately rather than three queries later. On the real data it reports the
things that actually need handling: 775 orders with no line items, 547 orders
carrying more than one review, 8 delivered orders with no delivery timestamp.

---

## Repository layout

```
sql/
  00_compat.sql            DuckDB shims for PostgreSQL built-ins
  01_staging/              8 views: typing, cleaning, deduplication, date arithmetic
  02_marts/                6 tables: the star schema
  03_analysis/             23 queries, one question each
scripts/
  build_db.py              CSV → DuckDB, + data-quality report
  run_analysis.py          run all analysis queries → CSV + dashboard
  export_marts.py          star schema → CSV, for Power BI
  make_sample_data.py      generate a calibrated stand-in dataset
  dashboard_template.html  the report; data injected at build time
powerbi/
  01_data_model.md         relationships, model hygiene, the grain trap
  02_measures.dax          ~40 measures, commented
  03_report_pages.md       page-by-page visual specification
output/
  tables/                  one CSV per analysis query
  dashboard/index.html     the rendered four-page report
```

---

## Analysis decisions worth defending

**Delivered orders only, for every revenue figure.** Cancelled and undelivered
orders are counted separately, never in GMV. Including them inflates the most
recent months most, because that is where in-flight orders concentrate — which is
exactly where a trend line gets read.

**`customer_unique_id`, never `customer_id`.** Olist mints a fresh `customer_id`
per order. Grouping on it returns a repeat rate of exactly zero, which is the most
commonly published false finding from this dataset.

**`order_item_id` is a sequence number, not a product key.** Counting rows on the
item table to get "orders" inflates the figure by ~14%. Order counts come from
`fct_orders` or `COUNT(DISTINCT order_id)`, always.

**Late rate is computed over orders where lateness is defined.** Delivered orders
with no delivery timestamp are excluded from the denominator rather than silently
counted as on time.

**An observation window on every retention metric.** A customer who first bought
last month has not failed to return; they have not had the chance. First-order
cohorts are cut 180 days before the end of the data, and only then compared.

**A stable analysis window for every growth figure.** September 2016 has a handful
of orders and the data stops mid-October 2018. `dim_date.is_stable_window` marks
Jan 2017 – Aug 2018; the dashboard greys the excluded months rather than hiding
them, so the reader can see the exclusion was deliberate.

**Annualisation from the trailing twelve months, not by halving the period.** The
dataset spans ~25 months of steep, uneven ramp-up. Dividing the total by two would
overstate the run rate substantially. The factor is 0.7692, computed in
`11_detractor_value.sql`.

**Sellers below 20 delivered orders are excluded from every decile.** With five
orders a seller can post a 100% miss rate by accident, and letting those rows into
a ranking makes the worst decile look far worse than any addressable population.

**Duplicate reviews are deduplicated to the most recent per order.** 547 orders
carry re-submitted reviews; left in place they double-count orders in every join.

**Platform-basis versus ranked-basis shares are reported separately.** A decile's
share of "all orders" and its share of "orders among ranked sellers" are different
numbers; `06_seller_quality.sql` returns both so a written claim can name the one
it uses.

---

## What this analysis cannot see

No cost of goods, no commission rate, no marketing spend, no basket-abandonment
events, no page views. Gross margin and conversion are out of reach, and **every
figure in this project is stated in GMV or in operational units, never in profit.**

Review text is present but not analysed. Portuguese free-text classification would
separate "arrived late" from "wrong item sent", which is the weakest link in the
seller-quality finding — the analysis can show that the bottom decile generates
disproportionate complaints, but not reliably why.

The largest gap is the absence of any experimental capability. Recommendation 1
should ship as a controlled rollout across a seller cohort, not a platform-wide
policy change, precisely because the counterfactual it rests on — that a
punctual-by-enforcement seller behaves like a naturally punctual one — is an
assumption this dataset cannot test.

---

## Source

[Brazilian E-Commerce Public Dataset by Olist](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce),
Kaggle. 99,441 orders placed between September 2016 and October 2018, across
96,096 customers and 2,970 active sellers.
