# Power BI data model

## What to load

Load the six mart tables, not the raw CSVs. The SQL layer has already done the
cleaning, the type casting, the deduplication and the derived date arithmetic, and
repeating that work in Power Query would create a second source of truth that
drifts from the SQL.

Two ways to connect:

**Option A — DuckDB via ODBC (preferred).** Install the DuckDB ODBC driver, point a
DSN at `olist.duckdb`, and import the six mart tables. Import mode, not
DirectQuery: the whole model is under 15 MB compressed and DirectQuery would
throw away the VertiPaq compression that makes this model fast.

**Option B — CSV extracts.** `python scripts/export_marts.py` writes the six mart
tables to `output/marts/*.csv`. Load the folder in Power Query. Slower to refresh
but needs no driver, which matters if you are handing the `.pbix` to someone else.

Row counts below are for the real Kaggle dataset; the generated sample is within a
few per cent of each.

| Table | Grain | Rows (real data) | Type |
|---|---|---|---|
| `fct_orders` | one row per order | 99,441 | Fact |
| `fct_order_items` | one row per unit sold | 112,650 | Fact |
| `dim_date` | one row per calendar day | ~790 | Dimension |
| `dim_customer` | one row per `customer_id` | 99,441 | Dimension |
| `dim_product` | one row per product | 32,951 | Dimension |
| `dim_seller` | one row per seller | 3,095 | Dimension |

## Relationships

```
dim_date[date_key]        1 ──→ *  fct_orders[purchase_date]        single, active
dim_date[date_key]        1 ──→ *  fct_order_items[purchase_date]   single, INACTIVE
dim_customer[customer_id] 1 ──→ *  fct_orders[customer_id]          single
dim_product[product_id]   1 ──→ *  fct_order_items[product_id]      single
dim_seller[seller_id]     1 ──→ *  fct_order_items[seller_id]       single
fct_orders[order_id]      1 ──→ *  fct_order_items[order_id]        single
```

Every relationship is single-direction, from the one side to the many side. Do not
turn on bi-directional filtering to "make a visual work" — it creates ambiguous
filter paths in a two-fact model and produces numbers that are wrong in ways that
are very hard to spot later. If a visual needs a dimension to reach the far fact
table, route it through `fct_orders[order_id]` or use `CROSSFILTER` inside the one
measure that needs it.

### Why the second date relationship is inactive

`dim_date` can only have one active relationship path to `fct_order_items`, and
there are two candidates: directly on `purchase_date`, or indirectly through
`fct_orders`. Leaving the direct one inactive and letting item-level measures
filter through `fct_orders` keeps a single filter path, so an order-level date
slicer and an item-level measure always agree. Activate it with `USERELATIONSHIP`
only inside a measure that genuinely needs to bypass the order table.

## Model hygiene

Set these before building any visual. Each one prevents a specific, common failure.

1. **Mark `dim_date` as a date table** (Table tools → Mark as date table →
   `date_key`). Without this the time-intelligence functions silently return blanks
   at year boundaries.
2. **Hide every raw numeric column on both fact tables.** Users should reach
   `order_gmv` through the `Total GMV` measure, never by dragging the column and
   getting an implicit `SUM` that ignores the delivered-only filter. Hide
   `order_gmv`, `item_revenue`, `freight_value`, `item_gmv`, `delivery_days`,
   `review_score`, `days_vs_promise`.
3. **Hide every key column**: `order_id`, `customer_id`, `product_id`, `seller_id`,
   `date_key`, `purchase_date`. Keys are for the engine, not the field list.
4. **Set summarisation to "Don't summarize"** on any numeric column you must leave
   visible — `quality_decile`, `review_score`, `customer_order_seq`. Power BI will
   otherwise offer to average a decile number, which is meaningless.
5. **Sort `month_name` by `month_no`** and `promise_bucket` by `bucket_order`, or
   your axes come out alphabetically: April, August, December.
6. **Create a measure table.** New table → `_Measures = {BLANK()}`, hide the
   column, park every measure there. Thirty measures scattered across two fact
   tables is unnavigable within a week.

## The grain trap

This is the single most important thing to get right in this model, and the
mistake is silent.

`fct_order_items[order_item_id]` is **not** a product identifier. It is a sequence
number within the order: 1, 2, 3. Two units of the same product appear as two rows.

Consequently:

- `COUNTROWS(fct_order_items)` = **units sold**, not orders.
- `DISTINCTCOUNT(fct_order_items[order_id])` = **orders**.
- Counting rows on the item table to get orders inflates the number by 14–16%,
  because the average order carrying items holds about 1.14 of them on the real
  data and 1.16 on the generated sample.
- **AOV must be built from `fct_orders`.** Dividing item-table revenue by
  item-table rows gives average *item* value and calls it average *order* value.

The same trap applies to customers. `dim_customer[customer_id]` is a per-order key
— Olist mints a fresh one for every order. Person-level questions must use
`customer_unique_id`. Using `customer_id` returns a repeat rate of exactly zero,
which is the most commonly published false finding from this dataset.
