# Report build: four pages

The rendered version of this report is `output/dashboard/index.html`, built from
the same queries. Use it as the visual reference while building — every number in
it comes from `output/tables/*.csv`, so you can check a Power BI visual against
the matching CSV and know immediately whether the DAX is right.

## Canvas and theme

16:9, 1280 × 720. Set a custom theme (View → Themes → Customize) with:

| Slot | Hex | Used for |
|---|---|---|
| Primary | `#0F6B63` | revenue, volume, anything neutral-positive |
| Warning | `#A9670F` | freight, seller handover |
| Negative | `#A83A33` | lateness, detractors, carrier transit |
| Positive | `#2B7A4B` | on-time, promoters |
| Text | `#16181C` / `#4A5059` | headings / body |
| Grid | `#EAE5DD` | gridlines only |

One accent, two alert colours, nothing else. Colour carries meaning in this report:
red always means "the customer had a bad time". Once red is also used decoratively,
that meaning is gone.

Turn gridlines down, drop every visual border, and set all currency to `R$ #,0`
with zero decimals except AOV. Nobody needs GMV to the centavo.

---

## Page 1 — Business overview

**Question the page answers:** is the business growing, and what is it made of?

| Position | Visual | Fields |
|---|---|---|
| Top strip | 4 × Card | `Total GMV`, `Orders`, `AOV`, `Freight % of Revenue` |
| Second strip | 4 × Card | `Avg Review Score`, `Detractor Rate`, `Late Rate`, `Repeat Rate` |
| Left, large | Line chart | Axis `dim_date[year_month]`, values `Total GMV` and `GMV 3M Avg` |
| Right, small | Stacked bar | `Item Revenue` and `Freight`, single bar, 100% stacked |
| Bottom left | Bar chart | Axis `dim_product[category]`, value `Item Revenue (by product)`, top 12 by value |
| Bottom right | Map or bar | `dim_customer[state]`, value `Total GMV`, colour saturation `Avg Delivery Days` |

Slicers, top right: `dim_date[year_month]` (between), `dim_customer[region]`,
`dim_product[category]`.

**Two things to get right.** Apply `Trend Colour` to the line so the ramp-up and
truncated months read as excluded rather than as a real dip and spike — this is the
single most misread part of the Olist dataset. And put the `Sample Warning` card in
the corner: once three slicers are on the page, it is easy to land on 40 orders and
read it as a trend.

---

## Page 2 — Delivery performance

**Question:** an order takes ~12 days. Which part is ours to fix?

| Position | Visual | Fields |
|---|---|---|
| Top strip | 4 × Card | `Avg Delivery Days`, `P90 Delivery Days`, `Late Rate`, `Promise Slack Days` |
| Top left | Stacked bar, horizontal | Axis: a two-value `is_late` column; values `Avg Approval Days`, `Avg Seller Handover Days`, `Avg Carrier Transit Days` |
| Top right | Line + column combo | Axis `year_month`; column `Orders`, line `Late Rate` on secondary axis |
| **Middle left** | **Stacked bar, horizontal** | Axis `any_deadline_missed`; values `Avg Seller Handover Days`, `Avg Carrier Transit Days` |
| **Middle right** | **Column chart** | Axis: days-past-deadline bucket; value `Late Rate`, data labels on |
| Lower | Scatter | X `Avg Delivery Days`, Y `Late Rate`, size `Orders`, detail `dim_customer[state]` |
| Bottom | Table | Seller region × customer region, with `Orders`, `Freight % of Revenue`, `Avg Delivery Days`, `Late Rate` |

**The deadline pair in the middle is the page.** It carries the first
recommendation and it works because the two bars answer the obvious objection
before it is raised: orders that missed the deadline spend four times as long in
seller handover and *the same* time in carrier transit. Put those two visuals side
by side so the reader sees the mechanism and the dose-response in one glance, and
title them with the finding — "The deadline we already set, unenforced", not
"Avg Handover Days by Deadline Missed".

Add a card with `Late Rate Multiple: Missed vs Met` beside them. A single "3.8×"
does more work in a review than either chart alone.

The scatter below is deliberately the *undramatic* visual: lateness tracks
slowness, as you would expect. It is there to close off the tempting wrong answer
— "just quote later dates" — by showing the promise already carries twelve days of
slack. Add a trend line and label it with the correlation.

For the lane table, use conditional formatting on `Freight % of Revenue` with
`Service Flag`, and add a `is_intra_region` filter so a reader can toggle between
"same region" and "crossing regions" and watch both columns roughly double.

---

## Page 3 — Customer experience

**Question:** what do customers do about bad service, and who causes it?

| Position | Visual | Fields |
|---|---|---|
| Top left | Column chart | Axis `review_score`, value `Reviewed Orders` |
| Top right | **Line + column combo** | Axis `promise_bucket` (sorted by `bucket_order`); column `Reviewed Orders`, line `Avg Review Score` on secondary axis |
| Middle | Column + line | Axis seller `quality_decile`; column share of detractors, line `Late Rate` |
| Bottom left | Column chart | Axis first-order `review_score`, value repeat rate |
| Bottom right | Table | RFM segment, `Customers`, `% of GMV`, `AOV` |

**The cliff chart, top right, is the most important visual in the report.** Fix
the secondary axis to 0–5 so the drop is not exaggerated by autoscaling, and sort
the axis by `bucket_order` or it will come out alphabetically and the cliff will
disappear into noise. The shape is the argument: rating is flat across every
early-delivery bucket and falls off a ledge the moment an order is one day late.
That is what justifies spending on **preventing the breach** — enforcing the
shipping deadline — rather than on shaving days off an already-fast median. Be
ready for the obvious counter in a review: "so quote later dates". The padding
counterfactual on the previous page is the answer, and it is worth having the
number to hand.

For the decile chart, colour the bottom two deciles in the negative colour and
leave the rest neutral. The point being made is concentration, and colour is what
makes concentration legible at a glance.

---

## Page 4 — Recommendations

Not a chart page. This is where most portfolio dashboards stop one page early, and
it is the page an interviewer actually reads.

Layout: a full-width banner card with the total annual impact, then three
recommendation blocks stacked vertically. Each block:

- number, title, and a one-line time-and-cost tag
- **What the data shows** — three sentences, each containing a figure from the model
- **The move** — the specific action, not a theme
- three metric tiles: the operational change, the volume affected, the money
- **Impact** — the annual figure
- **Assumptions and limits** — in smaller, grey text

Build the text with `Sample Warning`-style dynamic measures so the numbers update
with the model rather than being typed into text boxes. A hardcoded number in a
text box is a number that will be wrong after the next refresh, and it is the
detail that separates a report from a screenshot.

Keep the assumptions block. Naming the thing the data cannot settle — the attach
rate in recommendation 2, the fact that freight is customer-paid in recommendation
3 — is what makes the rest of the numbers credible.

---

## Interactions and performance

- Edit interactions so the KPI cards **do not** cross-filter. A reader clicking a
  bar expects the detail visuals to filter, not the headline totals to move.
- Set the lane and category tables to filter other visuals but not be filtered by
  them, or a two-click sequence can empty the page.
- Add drill-through from category and state into a detail page, filtered by
  `dim_product[category]` or `dim_customer[state]`.
- Sync the date slicer across all four pages; do not sync the category slicer,
  since pages 2 and 3 are operational and category rarely applies.
- Use Performance Analyzer on page 3. If the RFM table is slow, the
  `Repeat Customers` measure is the cause — it materialises a customer-level
  summary at query time. Pre-compute it into a column in `fct_orders` if the page
  crosses a second to render.
