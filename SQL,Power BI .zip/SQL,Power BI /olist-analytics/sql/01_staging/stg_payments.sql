-- stg_payments — payment lines collapsed to one row per order.
--
-- An order can be split across several payment records (e.g. two vouchers plus a
-- credit card). We keep the split detail available but expose an order-grain view
-- so payments can be joined 1:1 onto fct_orders without fanning out revenue.
--
-- payment_installments is the headline instalment count on the largest payment
-- line, not a sum: an order paid in 10x on a card plus a R$5 voucher is a "10x
-- order", not an "11x order".

CREATE OR REPLACE VIEW stg_payment_lines AS
SELECT
    order_id,
    payment_sequential          AS payment_seq,
    lower(payment_type)         AS payment_type,
    payment_installments        AS installments,
    CAST(payment_value AS DOUBLE) AS payment_value
FROM raw_order_payments
WHERE payment_type <> 'not_defined';


CREATE OR REPLACE VIEW stg_payments AS
WITH ranked AS (
    SELECT
        *,
        row_number() OVER (
            PARTITION BY order_id
            ORDER BY payment_value DESC, payment_seq
        ) AS rn
    FROM stg_payment_lines
)
SELECT
    order_id,
    sum(payment_value)                                        AS payment_total,
    count(*)                                                  AS payment_line_count,
    max(installments) FILTER (WHERE rn = 1)                   AS installments,
    max(payment_type) FILTER (WHERE rn = 1)                   AS primary_payment_type,
    bool_or(payment_type = 'credit_card')                     AS used_credit_card,
    bool_or(payment_type = 'boleto')                          AS used_boleto,
    bool_or(payment_type = 'voucher')                         AS used_voucher
FROM ranked
GROUP BY order_id;
