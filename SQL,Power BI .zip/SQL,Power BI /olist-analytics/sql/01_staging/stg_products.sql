-- stg_products — product attributes with English category names attached.
--
-- Two cleaning decisions:
--   1. ~600 products have a NULL category. They are bucketed as 'unknown' rather
--      than dropped, because dropping them would quietly remove real revenue.
--   2. Volume is derived from the three dimension columns. Freight in this
--      dataset tracks dimensional weight far more closely than actual weight,
--      which becomes the basis of the freight analysis in 03_analysis.

CREATE OR REPLACE VIEW stg_products AS
SELECT
    p.product_id,
    coalesce(t.product_category_name_english,
             p.product_category_name,
             'unknown')                                        AS category,
    coalesce(p.product_category_name, 'unknown')               AS category_pt,
    p.product_weight_g                                         AS weight_g,
    p.product_length_cm                                        AS length_cm,
    p.product_height_cm                                        AS height_cm,
    p.product_width_cm                                         AS width_cm,
    (p.product_length_cm * p.product_height_cm * p.product_width_cm)
                                                               AS volume_cm3,
    p.product_photos_qty                                       AS photo_count,
    p.product_description_lenght                               AS description_length
FROM raw_products p
LEFT JOIN raw_category_translation t
       ON p.product_category_name = t.product_category_name;
