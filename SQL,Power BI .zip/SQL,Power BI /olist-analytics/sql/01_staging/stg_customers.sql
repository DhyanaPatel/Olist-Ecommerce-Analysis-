-- stg_customers.
--
-- Critical distinction in this dataset:
--   customer_id        — a per-order key. A person who orders twice gets two.
--   customer_unique_id — the actual person.
--
-- Every retention, repeat-rate and RFM question must use customer_unique_id.
-- Using customer_id instead makes the repeat rate exactly 0%, which is the
-- classic false finding people report from this dataset.
--
-- Region mapping follows the IBGE macro-regions, so state-level noise (27 states,
-- several with a few hundred orders) can be rolled up to five stable groups.

CREATE OR REPLACE VIEW stg_customers AS
SELECT
    customer_id,
    customer_unique_id,
    customer_zip_code_prefix                                   AS zip_prefix,
    initcap(customer_city)                                     AS city,
    upper(customer_state)                                      AS state,
    CASE upper(customer_state)
        WHEN 'SP' THEN 'Southeast' WHEN 'RJ' THEN 'Southeast'
        WHEN 'MG' THEN 'Southeast' WHEN 'ES' THEN 'Southeast'
        WHEN 'PR' THEN 'South'     WHEN 'SC' THEN 'South'
        WHEN 'RS' THEN 'South'
        WHEN 'BA' THEN 'Northeast' WHEN 'PE' THEN 'Northeast'
        WHEN 'CE' THEN 'Northeast' WHEN 'MA' THEN 'Northeast'
        WHEN 'PB' THEN 'Northeast' WHEN 'RN' THEN 'Northeast'
        WHEN 'AL' THEN 'Northeast' WHEN 'PI' THEN 'Northeast'
        WHEN 'SE' THEN 'Northeast'
        WHEN 'GO' THEN 'Central-West' WHEN 'DF' THEN 'Central-West'
        WHEN 'MT' THEN 'Central-West' WHEN 'MS' THEN 'Central-West'
        WHEN 'AM' THEN 'North' WHEN 'PA' THEN 'North'
        WHEN 'RO' THEN 'North' WHEN 'TO' THEN 'North'
        WHEN 'AC' THEN 'North' WHEN 'AP' THEN 'North'
        WHEN 'RR' THEN 'North'
        ELSE 'Unknown'
    END                                                        AS region
FROM raw_customers;
