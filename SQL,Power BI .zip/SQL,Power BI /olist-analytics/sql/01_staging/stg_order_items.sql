-- stg_order_items — one row per physical unit sold.
--
-- Note on grain: order_item_id is NOT a product identifier, it is a sequence
-- number within the order (1, 2, 3...). Two units of the same product appear as
-- two rows. So count(*) is units sold, and count(DISTINCT order_id) is orders.
-- Getting this wrong is the single most common error on this dataset — it
-- inflates "orders" by ~14% because the average order with items carries 1.14.
--
-- Freight is charged per item, not per order. Summing freight_value at order
-- level is therefore correct, but comparing it against a single item's price is
-- not, which matters for the freight-ratio analysis downstream.

CREATE OR REPLACE VIEW stg_order_items AS
SELECT
    order_id,
    order_item_id                     AS item_seq,
    product_id,
    seller_id,
    shipping_limit_date               AS shipping_deadline,
    CAST(price AS DOUBLE)             AS item_revenue,
    CAST(freight_value AS DOUBLE)     AS freight_value,
    CAST(price AS DOUBLE) + CAST(freight_value AS DOUBLE) AS item_gmv
FROM raw_order_items;
