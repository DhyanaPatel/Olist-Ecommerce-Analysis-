-- stg_reviews — one row per order.
--
-- A small number of orders carry more than one review row (re-submissions and a
-- handful of duplicated review_ids). Left as-is they double-count orders in any
-- join, so we deduplicate to the most recent review per order: the latest score
-- is the one that reflects the customer's settled opinion.

CREATE OR REPLACE VIEW stg_reviews AS
WITH ranked AS (
    SELECT
        order_id,
        review_id,
        review_score,
        review_creation_date,
        review_answer_timestamp,
        -- Free-text presence is a useful signal even without reading Portuguese:
        -- customers who bother to type are disproportionately unhappy.
        (review_comment_message IS NOT NULL
         AND length(trim(review_comment_message)) > 0)          AS has_comment,
        length(coalesce(review_comment_message, ''))            AS comment_length,
        row_number() OVER (
            PARTITION BY order_id
            ORDER BY review_creation_date DESC, review_id
        ) AS rn
    FROM raw_order_reviews
)
SELECT
    order_id,
    review_id,
    review_score,
    review_creation_date                                       AS reviewed_at,
    (CAST(review_answer_timestamp AS DATE) - CAST(review_creation_date AS DATE))
                                                               AS response_days,
    has_comment,
    comment_length,
    (review_score <= 2)                                        AS is_detractor,
    (review_score = 5)                                         AS is_promoter
FROM ranked
WHERE rn = 1;
