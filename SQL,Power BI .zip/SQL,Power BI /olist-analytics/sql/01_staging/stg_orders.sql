-- stg_orders — one row per order, with the delivery clock decomposed.
--
-- The Olist order table stores five timestamps. Most of the operational story in
-- this dataset lives in the gaps between them, so we compute those gaps once here
-- rather than repeating date arithmetic in every downstream query.
--
--   purchase -> approved            payment authorisation lag
--   approved -> delivered_carrier   seller handover (seller's responsibility)
--   carrier  -> delivered_customer  carrier transit (logistics' responsibility)
--   estimated vs delivered          the promise the customer actually saw
--
-- delivery_days is measured on calendar days from purchase to customer receipt,
-- which is what the customer experiences and what the review is written against.

CREATE OR REPLACE VIEW stg_orders AS
SELECT
    order_id,
    customer_id,
    order_status,

    order_purchase_timestamp                                   AS purchased_at,
    order_approved_at                                          AS approved_at,
    order_delivered_carrier_date                               AS handed_to_carrier_at,
    order_delivered_customer_date                              AS delivered_at,
    order_estimated_delivery_date                              AS promised_at,

    CAST(order_purchase_timestamp AS DATE)                     AS purchase_date,
    date_trunc('month', order_purchase_timestamp)              AS purchase_month,

    -- Stage durations, in whole days. NULL where the stage has not happened.
    -- Date subtraction is used rather than a date_diff() function because the
    -- integer-day result is identical on PostgreSQL and DuckDB.
    (CAST(order_approved_at AS DATE) - CAST(order_purchase_timestamp AS DATE))
                                                               AS approval_days,
    (CAST(order_delivered_carrier_date AS DATE) - CAST(order_approved_at AS DATE))
                                                               AS seller_handover_days,
    (CAST(order_delivered_customer_date AS DATE) - CAST(order_delivered_carrier_date AS DATE))
                                                               AS carrier_transit_days,
    (CAST(order_delivered_customer_date AS DATE) - CAST(order_purchase_timestamp AS DATE))
                                                               AS delivery_days,
    (CAST(order_estimated_delivery_date AS DATE) - CAST(order_purchase_timestamp AS DATE))
                                                               AS promised_days,

    -- Positive = late. Negative = arrived ahead of the promised date.
    (CAST(order_delivered_customer_date AS DATE) - CAST(order_estimated_delivery_date AS DATE))
                                                               AS days_vs_promise,

    CASE
        WHEN order_status <> 'delivered'                  THEN NULL
        WHEN order_delivered_customer_date IS NULL        THEN NULL
        WHEN order_delivered_customer_date
             > order_estimated_delivery_date              THEN TRUE
        ELSE FALSE
    END                                                        AS is_late,

    (order_status = 'delivered')                               AS is_delivered,
    (order_status = 'canceled')                                AS is_cancelled
FROM raw_orders;
