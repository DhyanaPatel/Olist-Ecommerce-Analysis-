-- stg_sellers — seller location, with the same region rollup used for customers
-- so that buyer region and seller region are directly comparable.

CREATE OR REPLACE VIEW stg_sellers AS
SELECT
    seller_id,
    seller_zip_code_prefix                                     AS zip_prefix,
    initcap(seller_city)                                       AS city,
    upper(seller_state)                                        AS state,
    CASE upper(seller_state)
        WHEN 'SP' THEN 'Southeast' WHEN 'RJ' THEN 'Southeast'
        WHEN 'MG' THEN 'Southeast' WHEN 'ES' THEN 'Southeast'
        WHEN 'PR' THEN 'South'     WHEN 'SC' THEN 'South'
        WHEN 'RS' THEN 'South'
        WHEN 'BA' THEN 'Northeast' WHEN 'PE' THEN 'Northeast'
        WHEN 'CE' THEN 'Northeast' WHEN 'MA' THEN 'Northeast'
        WHEN 'PB' THEN 'Northeast' WHEN 'RN' THEN 'Northeast'
        WHEN 'AL' THEN 'Northeast' WHEN 'PI' THEN 'Northeast'
        WHEN 'SE' THEN 'Northeast'
        WHEN 'GO' THEN 'Central-West' WHEN 'DF' THEN 'Central-West'
        WHEN 'MT' THEN 'Central-West' WHEN 'MS' THEN 'Central-West'
        WHEN 'AM' THEN 'North' WHEN 'PA' THEN 'North'
        WHEN 'RO' THEN 'North' WHEN 'TO' THEN 'North'
        WHEN 'AC' THEN 'North' WHEN 'AP' THEN 'North'
        WHEN 'RR' THEN 'North'
        ELSE 'Unknown'
    END                                                        AS region
FROM raw_sellers;
