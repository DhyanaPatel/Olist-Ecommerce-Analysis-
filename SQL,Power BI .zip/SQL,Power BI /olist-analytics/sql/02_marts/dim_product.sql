-- dim_product — product grain, with a size band used for freight analysis.

CREATE OR REPLACE TABLE dim_product AS
SELECT
    product_id,
    category,
    category_pt,
    weight_g,
    volume_cm3,
    photo_count,
    description_length,
    CASE
        WHEN weight_g IS NULL           THEN 'unknown'
        WHEN weight_g <    500          THEN 'XS (<0.5kg)'
        WHEN weight_g <  2000           THEN 'S (0.5-2kg)'
        WHEN weight_g < 10000           THEN 'M (2-10kg)'
        WHEN weight_g < 30000           THEN 'L (10-30kg)'
        ELSE                                 'XL (30kg+)'
    END                                                        AS weight_band,
    CASE
        WHEN volume_cm3 IS NULL         THEN 'unknown'
        WHEN volume_cm3 <   5000        THEN 'XS'
        WHEN volume_cm3 <  20000        THEN 'S'
        WHEN volume_cm3 <  60000        THEN 'M'
        WHEN volume_cm3 < 150000        THEN 'L'
        ELSE                                 'XL'
    END                                                        AS volume_band
FROM stg_products;
