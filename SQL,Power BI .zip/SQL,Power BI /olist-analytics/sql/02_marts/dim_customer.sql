-- dim_customer — keyed on customer_id so it joins 1:1 to fct_orders, but
-- carrying customer_unique_id so person-level analysis stays one GROUP BY away.

CREATE OR REPLACE TABLE dim_customer AS
SELECT
    customer_id,
    customer_unique_id,
    zip_prefix,
    city,
    state,
    region
FROM stg_customers;
