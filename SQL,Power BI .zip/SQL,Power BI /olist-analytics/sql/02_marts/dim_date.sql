-- dim_date — a contiguous calendar spanning the transaction window.
--
-- Built from the data's own min/max so it never runs short, and marked with
-- is_stable_window: the first four and last two months of Olist's history are
-- ramp-up and truncation artefacts (Sept 2016 has a handful of orders; Sept-Oct
-- 2018 is cut off mid-month). Every trend or growth-rate claim in this project
-- is made on the stable window only, and the dashboard says so on the chart.
--
-- Dialect note: this is the one file that differs between engines. DuckDB's
-- generate_series over dates returns a list, so it needs UNNEST; PostgreSQL
-- returns rows directly and the UNNEST should be removed.

CREATE OR REPLACE TABLE dim_date AS
WITH bounds AS (
    SELECT
        date_trunc('month', min(purchased_at))                             AS lo,
        date_trunc('month', max(purchased_at)) + INTERVAL '1 month'
                                               - INTERVAL '1 day'          AS hi
    FROM stg_orders
),
days AS (
    SELECT CAST(UNNEST(generate_series(lo, hi, INTERVAL '1 day')) AS DATE) AS d
    FROM bounds
)
SELECT
    d                                                          AS date_key,
    CAST(EXTRACT(YEAR    FROM d) AS INTEGER)                   AS year,
    CAST(EXTRACT(QUARTER FROM d) AS INTEGER)                   AS quarter,
    CAST(EXTRACT(MONTH   FROM d) AS INTEGER)                   AS month_no,
    CASE CAST(EXTRACT(MONTH FROM d) AS INTEGER)
        WHEN  1 THEN 'Jan' WHEN  2 THEN 'Feb' WHEN  3 THEN 'Mar'
        WHEN  4 THEN 'Apr' WHEN  5 THEN 'May' WHEN  6 THEN 'Jun'
        WHEN  7 THEN 'Jul' WHEN  8 THEN 'Aug' WHEN  9 THEN 'Sep'
        WHEN 10 THEN 'Oct' WHEN 11 THEN 'Nov' ELSE 'Dec'
    END                                                        AS month_name,
    CAST(EXTRACT(YEAR FROM d) AS VARCHAR) || '-' ||
        lpad(CAST(EXTRACT(MONTH FROM d) AS VARCHAR), 2, '0')   AS year_month,
    CAST(date_trunc('month', d) AS DATE)                       AS month_start,
    CAST(EXTRACT(DOW FROM d) AS INTEGER)                       AS day_of_week_no,
    CASE CAST(EXTRACT(DOW FROM d) AS INTEGER)
        WHEN 0 THEN 'Sun' WHEN 1 THEN 'Mon' WHEN 2 THEN 'Tue'
        WHEN 3 THEN 'Wed' WHEN 4 THEN 'Thu' WHEN 5 THEN 'Fri'
        ELSE 'Sat'
    END                                                        AS day_of_week,
    (CAST(EXTRACT(DOW FROM d) AS INTEGER) IN (0, 6))           AS is_weekend,
    -- Stable analysis window: full months carrying meaningful volume.
    (d >= DATE '2017-01-01' AND d < DATE '2018-09-01')         AS is_stable_window
FROM days
ORDER BY d;
