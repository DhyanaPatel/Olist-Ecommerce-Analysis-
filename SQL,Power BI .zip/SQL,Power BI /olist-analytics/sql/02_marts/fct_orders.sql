-- fct_orders — the order-grain fact table. One row per order.
--
-- This is the table to use for order counts, AOV, delivery SLA and review
-- scores. It is deliberately separate from fct_order_items: mixing the two
-- grains in one table is how AOV silently becomes "average item value".
--
-- Every order gets exactly one row, whether or not it has items, payments or a
-- review, so the order count here always reconciles to raw_orders.

CREATE OR REPLACE TABLE fct_orders AS
WITH items AS (
    SELECT
        order_id,
        count(*)                                               AS item_count,
        count(DISTINCT product_id)                             AS distinct_products,
        count(DISTINCT seller_id)                              AS distinct_sellers,
        sum(item_revenue)                                      AS item_revenue,
        sum(freight_value)                                     AS freight_value,
        sum(item_gmv)                                          AS order_gmv,
        max(missed_shipping_deadline)                          AS any_deadline_missed
    FROM fct_order_items
    GROUP BY order_id
),
first_order AS (
    -- Order sequence per PERSON (customer_unique_id), not per customer_id.
    SELECT
        o.order_id,
        c.customer_unique_id,
        row_number() OVER (
            PARTITION BY c.customer_unique_id
            ORDER BY o.purchased_at
        )                                                      AS customer_order_seq
    FROM stg_orders o
    JOIN stg_customers c USING (customer_id)
)
SELECT
    o.order_id,
    o.customer_id,
    f.customer_unique_id,
    f.customer_order_seq,
    (f.customer_order_seq = 1)                                 AS is_first_order,

    o.order_status,
    o.is_delivered,
    o.is_cancelled,
    o.purchased_at,
    o.purchase_date,
    o.purchase_month,
    o.delivered_at,
    o.promised_at,

    o.approval_days,
    o.seller_handover_days,
    o.carrier_transit_days,
    o.delivery_days,
    o.promised_days,
    o.days_vs_promise,
    o.is_late,

    coalesce(i.item_count, 0)                                  AS item_count,
    coalesce(i.distinct_products, 0)                           AS distinct_products,
    coalesce(i.distinct_sellers, 0)                            AS distinct_sellers,
    coalesce(i.item_revenue, 0)                                AS item_revenue,
    coalesce(i.freight_value, 0)                               AS freight_value,
    coalesce(i.order_gmv, 0)                                   AS order_gmv,
    i.any_deadline_missed,

    p.payment_total,
    p.installments,
    p.primary_payment_type,
    p.payment_line_count,

    r.review_score,
    r.is_detractor,
    r.is_promoter,
    r.has_comment,
    (r.review_score IS NOT NULL)                               AS has_review
FROM stg_orders o
LEFT JOIN items      i ON o.order_id = i.order_id
LEFT JOIN first_order f ON o.order_id = f.order_id
LEFT JOIN stg_payments p ON o.order_id = p.order_id
LEFT JOIN stg_reviews  r ON o.order_id = r.order_id;
