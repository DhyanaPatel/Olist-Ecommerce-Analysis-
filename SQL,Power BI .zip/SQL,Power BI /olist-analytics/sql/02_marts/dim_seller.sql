-- dim_seller — seller grain. Region uses the same mapping as dim_customer so
-- cross-region shipping lanes can be built by joining the two.

CREATE OR REPLACE TABLE dim_seller AS
SELECT
    seller_id,
    zip_prefix,
    city,
    state,
    region
FROM stg_sellers;
