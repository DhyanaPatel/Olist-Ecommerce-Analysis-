-- fct_order_items — the item-grain fact table. One row per unit sold.
--
-- This is the table Power BI connects to for anything sliced by product,
-- category or seller. Revenue and freight are additive at this grain; order
-- counts are NOT (use DISTINCTCOUNT / count(DISTINCT order_id)).
--
-- Cancelled and unavailable orders are retained with their status so they can be
-- measured, but every headline revenue figure in this project filters to
-- delivered orders — revenue on an order that never arrived is not revenue.

CREATE OR REPLACE TABLE fct_order_items AS
SELECT
    i.order_id,
    i.item_seq,
    i.product_id,
    i.seller_id,
    o.customer_id,

    o.purchase_date,
    o.purchase_month,
    o.order_status,
    o.is_delivered,
    o.is_late,
    o.delivery_days,
    o.days_vs_promise,

    i.item_revenue,
    i.freight_value,
    i.item_gmv,
    -- Freight as a share of the item's own price. Capped at 5.0 for reporting so
    -- a handful of R$0.85 items with R$40 freight cannot drag a category average.
    CASE WHEN i.item_revenue > 0
         THEN least(i.freight_value / i.item_revenue, 5.0)
    END                                                        AS freight_ratio,

    i.shipping_deadline,
    -- Did the seller hand the parcel over by the contractual deadline?
    CASE WHEN o.handed_to_carrier_at IS NOT NULL
         THEN o.handed_to_carrier_at > i.shipping_deadline
    END                                                        AS missed_shipping_deadline
FROM stg_order_items i
JOIN stg_orders o USING (order_id);
