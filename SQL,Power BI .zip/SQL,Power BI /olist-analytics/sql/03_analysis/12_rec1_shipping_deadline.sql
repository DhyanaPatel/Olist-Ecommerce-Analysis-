-- 12_rec1_shipping_deadline — sizing for Recommendation 1.
--
-- The finding: Olist already stamps a contractual shipping deadline on every
-- order line, and nothing enforces it. Orders where a seller missed it are late
-- 24.4% of the time against 6.5%, and the mechanism is visible in the stage
-- decomposition — those orders spend ~7 extra days in seller handover and the
-- same time in carrier transit as everyone else.
--
-- Two scenarios, because "eliminate all deadline misses" is not a plan:
--
--   ceiling  — every deadline miss eliminated. Not achievable; it is the upper
--              bound, reported so the targeted scenario can be read against it.
--   targeted — the worst two seller deciles brought to the median miss rate among
--              sellers large enough to rank (20+ delivered orders). This is the
--              number the recommendation is made on, because it names a specific,
--              finite population of accounts.
--
-- The conversion assumption is stated explicitly: an order that no longer misses
-- its deadline is assumed to behave like the orders that already do not miss
-- theirs. That is the standard counterfactual for this kind of sizing, and it is
-- optimistic in one direction — a chronically late seller made punctual may
-- still be a worse-than-average seller in other ways.

WITH base AS (
    SELECT
        count(*) FILTER (WHERE any_deadline_missed)            AS missed_orders,
        count(*)                                               AS scoped_orders,
        avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE any_deadline_missed AND is_late IS NOT NULL)
                                                               AS late_missed,
        avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE NOT any_deadline_missed AND is_late IS NOT NULL)
                                                               AS late_clean,
        avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE any_deadline_missed)                 AS det_missed,
        avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE NOT any_deadline_missed)             AS det_clean,
        avg(review_score) FILTER (WHERE any_deadline_missed)   AS rev_missed,
        avg(review_score) FILTER (WHERE NOT any_deadline_missed)
                                                               AS rev_clean
    FROM fct_orders
    WHERE is_delivered
      AND any_deadline_missed IS NOT NULL
),
seller_rates AS (
    SELECT
        i.seller_id,
        count(DISTINCT i.order_id)                             AS orders,
        count(DISTINCT i.order_id) FILTER (WHERE i.missed_shipping_deadline)
                                                               AS missed
    FROM fct_order_items i
    WHERE i.is_delivered
    GROUP BY i.seller_id
    HAVING count(DISTINCT i.order_id) >= 20
),
ranked AS (
    SELECT *, ntile(10) OVER (ORDER BY missed * 1.0 / orders, seller_id) AS miss_decile
    FROM seller_rates
),
worst AS (
    SELECT
        count(*)                                               AS sellers,
        sum(orders)                                            AS orders,
        sum(missed)                                            AS misses
    FROM ranked
    WHERE miss_decile >= 9
),
worst_platform AS (
    -- The targeted population's footprint on the PLATFORM, counted distinctly.
    -- This has to be computed here rather than by summing the two decile shares
    -- in 20_deadline_by_seller: a handful of orders are shipped by a decile-9 AND
    -- a decile-10 seller, and adding the two shares double-counts them.
    SELECT count(DISTINCT o.order_id)                          AS platform_misses_caused
    FROM ranked r
    JOIN fct_order_items i ON r.seller_id = i.seller_id AND i.is_delivered
    JOIN fct_orders      o ON i.order_id  = o.order_id
    WHERE r.miss_decile >= 9
      AND o.any_deadline_missed
),
median_rate AS (
    -- The target: the MEDIAN MISS RATE AMONG RANKED SELLERS — those with 20+
    -- delivered orders. Precision matters here. It is not the median across all
    -- active sellers, which is 0% because most small sellers never miss at all.
    -- Stated correctly, the target is a level that half of the sellers big
    -- enough to rank already clear, which is what makes it defensible as
    -- achievable rather than aspirational.
    SELECT median(missed * 1.0 / orders)                       AS target_miss_rate
    FROM ranked
),
platform AS (
    SELECT
        count(*) FILTER (WHERE is_late)                        AS late_orders,
        count(*) FILTER (WHERE is_late IS NOT NULL)            AS sla_orders,
        count(*) FILTER (WHERE is_detractor)                   AS detractor_orders,
        count(*) FILTER (WHERE purchase_date >= DATE '2017-09-01'
                           AND purchase_date <  DATE '2018-09-01') * 1.0
            / count(*)                                         AS annualise
    FROM fct_orders
    WHERE is_delivered
),
value AS (
    -- Forward GMV lost per detractor, measured in 11_detractor_value.
    SELECT max(gap) AS gmv_per_detractor FROM (
        SELECT max(g) - min(g) AS gap FROM (
            SELECT CASE WHEN o.review_score <= 2 THEN 'd' ELSE 's' END AS k,
                   avg((SELECT coalesce(sum(r.order_gmv), 0) FROM fct_orders r
                        WHERE r.customer_unique_id = o.customer_unique_id
                          AND r.purchase_date >  o.purchase_date
                          AND r.purchase_date <= o.purchase_date + 180)) AS g
            FROM fct_orders o
            WHERE o.is_first_order AND o.is_delivered AND o.has_review
              AND o.review_score <> 3
              AND o.purchase_date <= (SELECT max(purchase_date) FROM fct_orders) - 180
            GROUP BY k
        )
    )
),
scenarios AS (
    SELECT 'ceiling'  AS scenario, 1 AS sort_order,
           b.missed_orders * 1.0                               AS misses_removed
    FROM base b
    UNION ALL
    SELECT 'targeted', 2,
           greatest(w.misses - w.orders * m.target_miss_rate, 0)
    FROM worst w, median_rate m
)
SELECT
    s.scenario,
    round(s.misses_removed)                                    AS deadline_misses_removed,
    b.missed_orders                                            AS total_deadline_misses,
    round(100.0 * s.misses_removed / b.missed_orders, 1)       AS pct_of_misses_addressed,
    (SELECT sellers FROM worst)                                AS sellers_in_targeted_scope,
    round(100.0 * (SELECT target_miss_rate FROM median_rate), 2)
                                                               AS target_miss_rate_pct,
    (SELECT platform_misses_caused FROM worst_platform)        AS targeted_platform_misses,
    round(100.0 * (SELECT platform_misses_caused FROM worst_platform)
          / b.missed_orders, 1)                                AS targeted_pct_of_platform_misses,

    round(100.0 * b.late_missed, 2)                            AS late_rate_when_missed_pct,
    round(100.0 * b.late_clean, 2)                             AS late_rate_when_clean_pct,
    round(100.0 * b.det_missed, 2)                             AS detractor_rate_when_missed_pct,
    round(100.0 * b.det_clean, 2)                              AS detractor_rate_when_clean_pct,
    round(b.rev_missed, 3)                                     AS avg_review_when_missed,
    round(b.rev_clean, 3)                                      AS avg_review_when_clean,

    -- Late deliveries and detractor reviews avoided, on the counterfactual that
    -- a fixed order behaves like an order that never missed its deadline.
    round(s.misses_removed * (b.late_missed - b.late_clean))   AS late_orders_avoided_period,
    round(s.misses_removed * (b.late_missed - b.late_clean) * p.annualise)
                                                               AS late_orders_avoided_per_year,
    round(s.misses_removed * (b.det_missed - b.det_clean))     AS detractors_avoided_period,
    round(s.misses_removed * (b.det_missed - b.det_clean) * p.annualise)
                                                               AS detractors_avoided_per_year,

    round(100.0 * p.late_orders / p.sla_orders, 2)             AS late_rate_before_pct,
    round(100.0 * (p.late_orders - s.misses_removed * (b.late_missed - b.late_clean))
          / p.sla_orders, 2)                                   AS late_rate_after_pct,

    round(v.gmv_per_detractor, 2)                              AS gmv_per_detractor,
    round(s.misses_removed * (b.det_missed - b.det_clean)
          * p.annualise * v.gmv_per_detractor, 2)              AS forward_gmv_recovered_per_year
FROM scenarios s, base b, platform p, value v
ORDER BY s.sort_order;
