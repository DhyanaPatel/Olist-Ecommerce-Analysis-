-- 09_first_order_effect — does the first delivery experience predict a second order?
--
-- Question: what is a bad first experience actually worth in lost revenue?
--
-- Method: take every person whose first order was delivered, and whose first
-- order happened early enough to have had a fair chance to reorder. That
-- observation-window filter is essential — someone who bought for the first time
-- in the last month of the data has not "failed to repeat", they simply have not
-- had time. Without it, the repeat rate is understated and the whole comparison
-- tilts toward whichever group happens to be more recent.
--
-- The window is 180 days, which covers the bulk of the repeat-gap distribution
-- (median gap between first and second order is around three months).

WITH first_orders AS (
    SELECT
        customer_unique_id,
        order_id,
        purchase_date,
        review_score,
        is_detractor,
        is_late,
        days_vs_promise,
        delivery_days,
        order_gmv
    FROM fct_orders
    WHERE is_first_order
      AND is_delivered
      AND has_review
),
observable AS (
    SELECT f.*
    FROM first_orders f
    WHERE f.purchase_date <= (SELECT max(purchase_date) FROM fct_orders) - 180
),
repeat_flag AS (
    SELECT
        o.*,
        CASE WHEN EXISTS (
            SELECT 1 FROM fct_orders r
            WHERE r.customer_unique_id = o.customer_unique_id
              AND r.purchase_date > o.purchase_date
              AND r.purchase_date <= o.purchase_date + 180
        ) THEN 1 ELSE 0 END                                    AS repeated_180d,
        (SELECT coalesce(sum(r.order_gmv), 0) FROM fct_orders r
         WHERE r.customer_unique_id = o.customer_unique_id
           AND r.purchase_date > o.purchase_date)              AS future_gmv
    FROM observable o
)
SELECT
    review_score,
    count(*)                                                   AS first_time_customers,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_cohort,
    round(100.0 * avg(repeated_180d), 3)                        AS repeat_rate_180d_pct,
    round(avg(future_gmv), 2)                                  AS avg_future_gmv,
    round(avg(order_gmv), 2)                                   AS avg_first_order_gmv,
    round(100.0 * avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE is_late IS NOT NULL), 2)
                                                               AS pct_late,
    round(avg(delivery_days), 2)                               AS avg_delivery_days,
    -- Repeat rate and forward value relative to the 5-star cohort: this is the
    -- number the retention recommendation is sized on.
    round(100.0 * avg(repeated_180d)
          - 100.0 * max(avg(repeated_180d)) OVER (), 3)         AS repeat_rate_gap_pts,
    round(avg(future_gmv) - max(avg(future_gmv)) OVER (), 2)   AS future_gmv_gap
FROM repeat_flag
GROUP BY review_score
ORDER BY review_score;
