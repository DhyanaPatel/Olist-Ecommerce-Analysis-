-- 10_shipping_lanes — seller region to customer region.
--
-- Question: which lanes are slow and expensive, and how much volume sits on them?
--
-- Lanes are built at item grain because the seller is an item attribute, then
-- deduplicated to one lane per order-seller pair so a two-unit order does not
-- count its lane twice.
--
-- The practical output is the cross-region share: how much of Olist's volume is
-- being shipped out of the Southeast to everywhere else, which is the volume a
-- regional fulfilment capability would address.

WITH lane_orders AS (
    SELECT DISTINCT
        i.order_id,
        i.seller_id,
        s.region                                               AS seller_region,
        c.region                                               AS customer_region,
        (s.region = c.region)                                  AS is_intra_region
    FROM fct_order_items i
    JOIN dim_seller   s USING (seller_id)
    JOIN fct_orders   o USING (order_id)
    JOIN dim_customer c ON o.customer_id = c.customer_id
    WHERE i.is_delivered
),
lane_freight AS (
    SELECT
        order_id,
        seller_id,
        sum(freight_value)                                     AS freight_value,
        sum(item_revenue)                                      AS item_revenue
    FROM fct_order_items
    WHERE is_delivered
    GROUP BY order_id, seller_id
)
SELECT
    l.seller_region,
    l.customer_region,
    l.is_intra_region,
    count(*)                                                   AS shipments,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_shipments,
    round(sum(f.item_revenue), 2)                              AS item_revenue,
    round(sum(f.freight_value), 2)                             AS freight_cost,
    round(avg(f.freight_value), 2)                             AS avg_freight,
    round(100.0 * sum(f.freight_value) / nullif(sum(f.item_revenue), 0), 2)
                                                               AS freight_pct_of_revenue,
    round(avg(o.delivery_days), 2)                             AS avg_delivery_days,
    round(quantile_cont(o.delivery_days, 0.90), 1)             AS p90_delivery_days,
    round(100.0 * avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE o.is_late IS NOT NULL), 2)
                                                               AS late_rate_pct,
    round(avg(o.review_score), 3)                              AS avg_review
FROM lane_orders l
JOIN lane_freight f ON l.order_id = f.order_id AND l.seller_id = f.seller_id
JOIN fct_orders   o ON l.order_id = o.order_id
WHERE l.seller_region <> 'Unknown'
  AND l.customer_region <> 'Unknown'
GROUP BY l.seller_region, l.customer_region, l.is_intra_region
HAVING count(*) >= 100
ORDER BY shipments DESC;
