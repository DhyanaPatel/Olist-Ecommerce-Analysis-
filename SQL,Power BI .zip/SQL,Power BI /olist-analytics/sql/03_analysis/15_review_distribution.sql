-- 15_review_distribution — the shape of the review score distribution.
--
-- Worth plotting rather than summarising to a mean. The distribution is J-shaped:
-- a large 5-star mass, a thin middle, and a second lump at 1 star. A mean of
-- ~4.16 describes neither of the two populations that actually exist, which is
-- why the analysis works with detractor rate as well as average score.

SELECT
    review_score,
    count(*)                                                   AS orders,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_reviews,
    round(sum(order_gmv), 2)                                   AS gmv,
    round(avg(order_gmv), 2)                                   AS aov,
    round(avg(delivery_days), 2)                               AS avg_delivery_days,
    round(100.0 * avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE is_late IS NOT NULL), 2)
                                                               AS late_rate_pct,
    round(100.0 * avg(CASE WHEN has_comment THEN 1.0 ELSE 0.0 END), 2)
                                                               AS commented_pct
FROM fct_orders
WHERE is_delivered AND has_review
GROUP BY review_score
ORDER BY review_score;
