-- 18_shipping_deadline — the contractual deadline the platform already has.
--
-- Question: Olist gives every seller a shipping_limit_date. What happens when
-- they miss it, and does missing it actually cause anything?
--
-- This is the strongest single predictor of a bad outcome in the dataset, and it
-- matters because the mechanism is already contractual — the deadline exists, it
-- is stamped on every order line, and nothing appears to enforce it.
--
-- On causation: the usual objection to a correlation like this is that some
-- hidden third factor drives both. Here the mechanism is visible in the stage
-- decomposition. Orders that miss the deadline take ~7 days longer in SELLER
-- HANDOVER and essentially the same time in CARRIER TRANSIT. The seller's delay
-- is not a symptom of a slow lane; it is the delay, passed straight through to
-- the customer. That is about as close to a causal read as observational data
-- gets, and the dose-response below reinforces it: the further past the
-- deadline, the worse the outcome, monotonically.

WITH scoped AS (
    SELECT
        o.order_id,
        o.any_deadline_missed                                  AS missed,
        o.seller_handover_days,
        o.carrier_transit_days,
        o.delivery_days,
        o.is_late,
        o.is_detractor,
        o.review_score,
        o.order_gmv
    FROM fct_orders o
    WHERE o.is_delivered
      AND o.any_deadline_missed IS NOT NULL
),
overall AS (
    SELECT
        CASE WHEN missed THEN 'Missed the deadline' ELSE 'Shipped on time' END
                                                               AS cohort,
        CASE WHEN missed THEN 2 ELSE 1 END                     AS sort_order,
        count(*)                                               AS orders,
        round(100.0 * count(*) / sum(count(*)) OVER (), 2)     AS pct_of_orders,
        round(avg(seller_handover_days), 2)                    AS avg_handover_days,
        round(avg(carrier_transit_days), 2)                    AS avg_transit_days,
        round(avg(delivery_days), 2)                           AS avg_delivery_days,
        round(100.0 * avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END)
              FILTER (WHERE is_late IS NOT NULL), 2)           AS late_rate_pct,
        round(100.0 * avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct,
        round(avg(review_score), 3)                            AS avg_review,
        round(sum(order_gmv), 2)                               AS gmv
    FROM scoped
    GROUP BY missed
)
SELECT * FROM overall ORDER BY sort_order;
