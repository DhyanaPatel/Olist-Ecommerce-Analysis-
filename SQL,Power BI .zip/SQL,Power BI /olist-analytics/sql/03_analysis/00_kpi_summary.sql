-- 00_kpi_summary — the headline numbers, in one row.
--
-- Every KPI on the dashboard's landing page resolves to this query, so the card
-- values and the written findings cannot drift apart.
--
-- Scope note: revenue KPIs are on delivered orders; the order/cancellation
-- counts are on all orders, because a cancellation rate computed on delivered
-- orders only would be zero by construction.

WITH all_orders AS (
    SELECT
        count(*)                                               AS orders_all,
        count(*) FILTER (WHERE is_delivered)                   AS orders_delivered,
        count(*) FILTER (WHERE is_cancelled)                   AS orders_cancelled,
        count(DISTINCT customer_unique_id)                     AS customers_all,
        min(purchase_date)                                     AS first_date,
        max(purchase_date)                                     AS last_date
    FROM fct_orders
),
delivered AS (
    SELECT
        sum(order_gmv)                                         AS gmv,
        sum(item_revenue)                                      AS item_revenue,
        sum(freight_value)                                     AS freight,
        avg(order_gmv)                                         AS aov,
        sum(item_count)                                        AS units,
        avg(delivery_days)                                     AS avg_delivery_days,
        quantile_cont(delivery_days, 0.90)                     AS p90_delivery_days,
        avg(promised_days)                                     AS avg_promised_days,
        avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE is_late IS NOT NULL)           AS late_rate,
        avg(review_score)                                      AS avg_review,
        avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END)      AS detractor_rate,
        avg(CASE WHEN is_promoter  THEN 1.0 ELSE 0.0 END)      AS promoter_rate,
        count(*) FILTER (WHERE is_detractor)                   AS detractor_orders,
        count(*) FILTER (WHERE is_late)                        AS late_orders,
        count(*) FILTER (WHERE is_late IS NOT NULL)            AS orders_with_sla_outcome,
        sum(order_gmv) FILTER (WHERE is_late)                  AS gmv_late
    FROM fct_orders
    WHERE is_delivered
),
repeat_stats AS (
    SELECT
        avg(CASE WHEN n > 1 THEN 1.0 ELSE 0.0 END)             AS repeat_rate
    FROM (SELECT customer_unique_id, count(*) AS n
          FROM fct_orders WHERE is_delivered GROUP BY 1)
),
supply AS (
    SELECT
        count(DISTINCT seller_id)                              AS sellers,
        count(DISTINCT product_id)                             AS products
    FROM fct_order_items
    WHERE is_delivered
)
SELECT
    a.first_date,
    a.last_date,
    a.orders_all,
    a.orders_delivered,
    a.orders_cancelled,
    round(100.0 * a.orders_cancelled / a.orders_all, 2)        AS cancel_rate_pct,
    a.customers_all,
    s.sellers,
    s.products,

    round(d.gmv, 2)                                            AS gmv,
    round(d.item_revenue, 2)                                   AS item_revenue,
    round(d.freight, 2)                                        AS freight,
    round(100.0 * d.freight / d.item_revenue, 2)               AS freight_pct_of_revenue,
    round(d.aov, 2)                                            AS aov,
    d.units,

    round(d.avg_delivery_days, 2)                              AS avg_delivery_days,
    round(d.p90_delivery_days, 1)                              AS p90_delivery_days,
    round(d.avg_promised_days, 2)                              AS avg_promised_days,
    round(d.avg_promised_days - d.avg_delivery_days, 2)        AS avg_promise_slack,
    round(100.0 * d.late_rate, 2)                              AS late_rate_pct,
    d.late_orders,
    d.orders_with_sla_outcome,
    round(d.gmv_late, 2)                                       AS gmv_late,

    round(d.avg_review, 3)                                     AS avg_review,
    round(100.0 * d.detractor_rate, 2)                         AS detractor_rate_pct,
    round(100.0 * d.promoter_rate, 2)                          AS promoter_rate_pct,
    d.detractor_orders,
    round(100.0 * r.repeat_rate, 2)                            AS repeat_rate_pct
FROM all_orders a, delivered d, repeat_stats r, supply s;
