-- 04_delivery_stages — where the delivery clock actually goes.
--
-- Question: an order takes ~12 days. Which part of that is ours to fix?
--
-- The total splits into three stages with three different owners:
--   approval_days        payments / fraud screening
--   seller_handover_days the seller, until the parcel reaches the carrier
--   carrier_transit_days the logistics partner
--
-- The comparison that matters is not the mean of each stage but how much each
-- stage differs between on-time and late orders. A stage with a high mean but
-- the same mean on both sides of the SLA is a constant, not a cause. Stage
-- variance is reported alongside the mean for exactly this reason.

WITH stages AS (
    SELECT
        CASE WHEN is_late THEN 'Late' ELSE 'On time' END       AS outcome,
        approval_days,
        seller_handover_days,
        carrier_transit_days,
        delivery_days
    FROM fct_orders
    WHERE is_delivered
      AND is_late IS NOT NULL
      AND seller_handover_days IS NOT NULL
      AND carrier_transit_days IS NOT NULL
),
by_outcome AS (
    SELECT
        outcome,
        count(*)                                               AS orders,
        avg(approval_days)                                     AS approval,
        avg(seller_handover_days)                              AS handover,
        avg(carrier_transit_days)                              AS transit,
        avg(delivery_days)                                     AS total,
        quantile_cont(seller_handover_days, 0.90)              AS handover_p90,
        quantile_cont(carrier_transit_days, 0.90)              AS transit_p90
    FROM stages
    GROUP BY outcome
)
SELECT
    outcome,
    orders,
    round(approval, 2)                                         AS approval_days,
    round(handover, 2)                                         AS seller_handover_days,
    round(transit, 2)                                          AS carrier_transit_days,
    round(total, 2)                                            AS total_delivery_days,
    round(handover_p90, 1)                                     AS handover_p90,
    round(transit_p90, 1)                                      AS transit_p90,
    -- Each stage as a share of the total clock for that outcome group.
    round(100.0 * approval / nullif(total, 0), 1)              AS pct_approval,
    round(100.0 * handover / nullif(total, 0), 1)              AS pct_handover,
    round(100.0 * transit  / nullif(total, 0), 1)              AS pct_transit,
    -- The gap versus on-time orders: this is the diagnostic column.
    round(approval - min(approval) OVER (), 2)                 AS approval_gap,
    round(handover - min(handover) OVER (), 2)                 AS handover_gap,
    round(transit  - min(transit)  OVER (), 2)                 AS transit_gap
FROM by_outcome
ORDER BY outcome;
