-- 21_lateness_correlation — does lateness track slowness, or thin padding?
--
-- This exists because the answer decides whether "quote later dates" is a
-- sensible recommendation, and because a correlation quoted in prose should be
-- reproducible from the repo rather than computed once in a chart and forgotten.
--
-- Three bases are returned, because they disagree and the disagreement is the
-- point:
--
--   all_states     — all 27 states, unweighted. Every state counts equally,
--                    including ones with a few hundred orders whose rates are
--                    noisy. This is the weakest correlation and the most
--                    conservative number to quote.
--   ranked_states  — states with 250+ delivered orders, unweighted. Drops the
--                    noise; this is what the dashboard scatter plots.
--   order_weighted — all states, weighted by order volume. Closest to "what a
--                    customer experiences", since it lets São Paulo count for
--                    what it actually is.
--
-- Whichever basis is used, the sign is positive: slower states are later. The
-- alternative hypothesis — that lateness comes from thin promise padding — would
-- require a NEGATIVE correlation with slack, and the slack column tests exactly
-- that.

WITH states AS (
    SELECT
        c.state,
        count(*)                                               AS orders,
        avg(o.delivery_days)                                   AS avg_delivery_days,
        avg(o.promised_days) - avg(o.delivery_days)            AS avg_promise_slack,
        avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE o.is_late IS NOT NULL)               AS late_rate
    FROM fct_orders o
    JOIN dim_customer c USING (customer_id)
    WHERE o.is_delivered
    GROUP BY c.state
),
bases AS (
    SELECT 'all_states'    AS basis, 1 AS sort_order, * FROM states
    UNION ALL
    SELECT 'ranked_states', 2, * FROM states WHERE orders >= 250
)
SELECT
    basis,
    count(*)                                                   AS states_included,
    sum(orders)                                                AS orders_covered,
    round(corr(avg_delivery_days, late_rate), 3)               AS r_late_vs_delivery_days,
    round(corr(avg_promise_slack, late_rate), 3)               AS r_late_vs_promise_slack,
    round(regr_slope(100 * late_rate, avg_delivery_days), 3)   AS pts_late_per_extra_day
FROM bases
GROUP BY basis, sort_order

UNION ALL

-- Order-weighted, computed longhand because DuckDB's corr() takes no weights.
SELECT
    'order_weighted',
    count(*),
    sum(orders),
    round(
        (sum(orders * avg_delivery_days * late_rate) / sum(orders)
         - (sum(orders * avg_delivery_days) / sum(orders))
         * (sum(orders * late_rate) / sum(orders)))
        / (sqrt(sum(orders * avg_delivery_days * avg_delivery_days) / sum(orders)
                - pow(sum(orders * avg_delivery_days) / sum(orders), 2))
         * sqrt(sum(orders * late_rate * late_rate) / sum(orders)
                - pow(sum(orders * late_rate) / sum(orders), 2))), 3),
    round(
        (sum(orders * avg_promise_slack * late_rate) / sum(orders)
         - (sum(orders * avg_promise_slack) / sum(orders))
         * (sum(orders * late_rate) / sum(orders)))
        / (sqrt(sum(orders * avg_promise_slack * avg_promise_slack) / sum(orders)
                - pow(sum(orders * avg_promise_slack) / sum(orders), 2))
         * sqrt(sum(orders * late_rate * late_rate) / sum(orders)
                - pow(sum(orders * late_rate) / sum(orders), 2))), 3),
    NULL
FROM states

ORDER BY 1;
