-- 16_service_trend — monthly service quality alongside monthly volume.
--
-- Question: did service hold up as volume grew?
--
-- This is the chart that tells you whether a marketplace is scaling or just
-- getting bigger. Plotting late rate against order volume on the same monthly
-- axis makes any capacity strain visible as a divergence.

SELECT
    d.year_month,
    d.month_start,
    bool_and(d.is_stable_window)                               AS is_stable,
    count(*)                                                   AS orders,
    round(avg(o.delivery_days), 2)                             AS avg_delivery_days,
    round(quantile_cont(o.delivery_days, 0.90), 1)             AS p90_delivery_days,
    round(avg(o.promised_days), 2)                             AS avg_promised_days,
    round(avg(o.seller_handover_days), 2)                      AS avg_handover_days,
    round(avg(o.carrier_transit_days), 2)                      AS avg_transit_days,
    round(100.0 * avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE o.is_late IS NOT NULL), 2)
                                                               AS late_rate_pct,
    round(avg(o.review_score), 3)                              AS avg_review,
    round(100.0 * avg(CASE WHEN o.is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct
FROM fct_orders o
JOIN dim_date d ON o.purchase_date = d.date_key
WHERE o.is_delivered
GROUP BY d.year_month, d.month_start
ORDER BY d.month_start;
