-- 06_seller_quality — seller performance deciles.
--
-- Question: is bad service spread evenly across the seller base, or concentrated
-- in a tail that could be managed individually?
--
-- Sellers with fewer than 20 delivered orders are excluded from the deciles:
-- with 5 orders a seller can post a 100% late rate by accident, and letting
-- those rows into the ranking makes the worst decile look far worse than any
-- real, addressable population. They are reported separately as a long-tail
-- aggregate so no revenue goes missing.

WITH seller_orders AS (
    SELECT DISTINCT
        i.seller_id,
        i.order_id
    FROM fct_order_items i
    WHERE i.is_delivered
),
seller_stats AS (
    SELECT
        s.seller_id,
        d.state                                                AS seller_state,
        d.region                                               AS seller_region,
        count(*)                                               AS orders,
        sum(o.order_gmv)                                       AS gmv,
        avg(o.seller_handover_days)                            AS avg_handover_days,
        avg(o.delivery_days)                                   AS avg_delivery_days,
        avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE o.is_late IS NOT NULL)         AS late_rate,
        avg(o.review_score)                                    AS avg_review,
        avg(CASE WHEN o.is_detractor THEN 1.0 ELSE 0.0 END)    AS detractor_rate,
        sum(CASE WHEN o.is_detractor THEN 1 ELSE 0 END)        AS detractors
    FROM seller_orders s
    JOIN fct_orders o USING (order_id)
    JOIN dim_seller  d USING (seller_id)
    GROUP BY s.seller_id, d.state, d.region
),
ranked AS (
    SELECT
        *,
        -- seller_id is included in the sort purely as a tie-break, so that
        -- sellers with identical detractor and late rates land in a stable
        -- decile and the whole pipeline is byte-reproducible across runs.
        ntile(10) OVER (ORDER BY detractor_rate, late_rate, seller_id)
                                                               AS quality_decile
    FROM seller_stats
    WHERE orders >= 20
),
platform AS (
    -- Platform-wide denominators. The per-decile figures below are shares of the
    -- RANKED population (sellers with 20+ orders), which is not the same as a
    -- share of the platform: an order with two sellers appears once per seller,
    -- and small sellers are excluded from the ranking entirely. Both bases are
    -- reported so a claim can name the one it is using.
    SELECT
        (SELECT count(*) FROM fct_orders WHERE is_delivered)   AS platform_orders,
        (SELECT count(*) FROM fct_orders
          WHERE is_delivered AND is_detractor)                 AS platform_detractors
),
decile_orders AS (
    -- Distinct platform orders touched by each decile's sellers, so the
    -- platform-basis shares below do not double-count multi-seller orders.
    SELECT
        r.quality_decile,
        count(DISTINCT s.order_id)                             AS distinct_orders,
        count(DISTINCT s.order_id) FILTER (WHERE o.is_detractor)
                                                               AS distinct_detractors
    FROM ranked r
    JOIN seller_orders s USING (seller_id)
    JOIN fct_orders    o USING (order_id)
    GROUP BY r.quality_decile
)
SELECT
    r.quality_decile,
    count(*)                                                   AS sellers,
    sum(r.orders)                                              AS seller_order_pairs,
    round(100.0 * sum(r.orders) / sum(sum(r.orders)) OVER (), 2)
                                                               AS pct_of_ranked_orders,
    round(sum(r.gmv), 2)                                       AS gmv,
    round(100.0 * sum(r.gmv) / sum(sum(r.gmv)) OVER (), 2)     AS pct_of_ranked_gmv,
    round(avg(r.avg_handover_days), 2)                         AS avg_handover_days,
    round(avg(r.avg_delivery_days), 2)                         AS avg_delivery_days,
    round(100.0 * sum(r.orders * r.late_rate) / sum(r.orders), 2)
                                                               AS late_rate_pct,
    round(sum(r.orders * r.avg_review) / sum(r.orders), 3)     AS avg_review,
    sum(r.detractors)                                          AS detractors,
    round(100.0 * sum(r.detractors) / sum(sum(r.detractors)) OVER (), 2)
                                                               AS pct_of_ranked_detractors,

    -- Platform basis: distinct orders and distinct detractor reviews, as a share
    -- of every delivered order and every 1-2 star review on the platform. These
    -- are the columns to quote in a written finding.
    max(d.distinct_orders)                                     AS platform_orders_touched,
    round(100.0 * max(d.distinct_orders) / max(p.platform_orders), 2)
                                                               AS pct_of_platform_orders,
    max(d.distinct_detractors)                                 AS platform_detractors_touched,
    round(100.0 * max(d.distinct_detractors) / max(p.platform_detractors), 2)
                                                               AS pct_of_platform_detractors
FROM ranked r
JOIN decile_orders d USING (quality_decile)
CROSS JOIN platform p
GROUP BY r.quality_decile
ORDER BY r.quality_decile;
