-- 02_category_performance — the commercial and operational profile of each
-- category, side by side.
--
-- Question: which categories are worth defending, and which ones are buying
-- revenue with freight subsidy and bad reviews?
--
-- Categories are usually ranked by revenue alone, which hides the trade-off.
-- Here each category carries its revenue share, its freight burden, its late
-- rate and its review score in one row, so a category that looks strong on
-- revenue and weak on everything else is immediately visible.

WITH cat AS (
    SELECT
        p.category,
        count(DISTINCT i.order_id)                             AS orders,
        count(*)                                               AS units,
        count(DISTINCT i.product_id)                           AS skus,
        count(DISTINCT i.seller_id)                            AS sellers,
        sum(i.item_revenue)                                    AS item_revenue,
        sum(i.freight_value)                                   AS freight,
        avg(i.item_revenue)                                    AS avg_price,
        avg(i.freight_value)                                   AS avg_freight,
        avg(p.weight_g)                                        AS avg_weight_g
    FROM fct_order_items i
    JOIN dim_product p USING (product_id)
    WHERE i.is_delivered
    GROUP BY p.category
),
ops AS (
    -- Delivery and review are order-level facts, so they are aggregated at order
    -- grain first and then attributed to the category of the order's items.
    -- An order spanning two categories contributes to both; that is intended,
    -- because the customer blames whichever product they were waiting for.
    SELECT
        p.category,
        avg(o.delivery_days)                                   AS avg_delivery_days,
        avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE o.is_late IS NOT NULL)         AS late_rate,
        avg(o.review_score)                                    AS avg_review,
        avg(CASE WHEN o.is_detractor THEN 1.0 ELSE 0.0 END)    AS detractor_rate
    FROM (SELECT DISTINCT order_id, product_id FROM fct_order_items WHERE is_delivered) oi
    JOIN dim_product p USING (product_id)
    JOIN fct_orders  o USING (order_id)
    GROUP BY p.category
)
SELECT
    c.category,
    c.orders,
    c.units,
    c.skus,
    c.sellers,
    round(c.item_revenue, 2)                                   AS item_revenue,
    round(100.0 * c.item_revenue / sum(c.item_revenue) OVER (), 2)
                                                               AS pct_of_revenue,
    round(100.0 * sum(c.item_revenue) OVER (ORDER BY c.item_revenue DESC)
          / sum(c.item_revenue) OVER (), 2)                    AS cumulative_pct,
    round(c.avg_price, 2)                                      AS avg_price,
    round(c.avg_freight, 2)                                    AS avg_freight,
    round(100.0 * c.freight / nullif(c.item_revenue, 0), 2)    AS freight_pct_of_revenue,
    round(c.avg_weight_g)                                      AS avg_weight_g,
    round(o.avg_delivery_days, 2)                              AS avg_delivery_days,
    round(100.0 * o.late_rate, 2)                              AS late_rate_pct,
    round(o.avg_review, 3)                                     AS avg_review,
    round(100.0 * o.detractor_rate, 2)                         AS detractor_rate_pct
FROM cat c
JOIN ops o USING (category)
WHERE c.category <> 'unknown'
ORDER BY c.item_revenue DESC;
