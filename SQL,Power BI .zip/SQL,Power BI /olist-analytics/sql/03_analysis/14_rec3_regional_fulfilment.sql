-- 14_rec3_regional_fulfilment — sizing for Recommendation 3.
--
-- The finding: 74% of active sellers sit in the Southeast, so every order to the North
-- and Northeast is a long-haul shipment. Those lanes pay roughly double the
-- freight of an intra-Southeast order as a share of item value, and take about
-- twice as long to arrive.
--
-- The proposal: recruit sellers into the Northeast, or place forward stock
-- there, so that the region's demand is served locally.
--
-- The benchmark used is the platform's own intra-Southeast freight ratio, not a
-- theoretical optimum: it is what Olist already achieves when seller and buyer
-- are in the same region, so it is an achievable target rather than an aspiration.
--
-- One important caveat, carried into the write-up: freight in this dataset is
-- paid by the customer, not by Olist. The saving below is money taken out of
-- customers' baskets in the regions with the worst service, not margin added to
-- Olist's P&L. The revenue case runs through conversion and repeat purchase,
-- which this dataset cannot measure directly.

WITH lanes AS (
    SELECT DISTINCT
        i.order_id,
        i.seller_id,
        s.region                                               AS seller_region,
        c.region                                               AS customer_region
    FROM fct_order_items i
    JOIN dim_seller   s USING (seller_id)
    JOIN fct_orders   o USING (order_id)
    JOIN dim_customer c ON o.customer_id = c.customer_id
    WHERE i.is_delivered
),
lane_value AS (
    SELECT
        l.seller_region,
        l.customer_region,
        f.order_id,
        f.seller_id,
        f.item_revenue,
        f.freight_value,
        o.delivery_days
    FROM lanes l
    JOIN (SELECT order_id, seller_id,
                 sum(item_revenue)  AS item_revenue,
                 sum(freight_value) AS freight_value
          FROM fct_order_items WHERE is_delivered
          GROUP BY order_id, seller_id) f
      ON l.order_id = f.order_id AND l.seller_id = f.seller_id
    JOIN fct_orders o ON l.order_id = o.order_id
),
benchmark AS (
    SELECT
        sum(freight_value) / sum(item_revenue)                 AS intra_se_freight_ratio,
        avg(delivery_days)                                     AS intra_se_delivery_days
    FROM lane_value
    WHERE seller_region = 'Southeast' AND customer_region = 'Southeast'
),
target_lanes AS (
    SELECT
        customer_region,
        count(*)                                               AS shipments,
        sum(item_revenue)                                      AS item_revenue,
        sum(freight_value)                                     AS freight_cost,
        sum(freight_value) / sum(item_revenue)                 AS freight_ratio,
        avg(delivery_days)                                     AS avg_delivery_days
    FROM lane_value
    WHERE seller_region = 'Southeast'
      AND customer_region IN ('Northeast', 'North')
    GROUP BY customer_region
),
annual AS (
    SELECT count(*) FILTER (WHERE purchase_date >= DATE '2017-09-01'
                              AND purchase_date <  DATE '2018-09-01') * 1.0
                  / count(*)                                   AS annualise
    FROM fct_orders WHERE is_delivered
)
SELECT
    t.customer_region,
    t.shipments,
    round(t.item_revenue, 2)                                   AS item_revenue_period,
    round(t.freight_cost, 2)                                   AS freight_cost_period,
    round(100.0 * t.freight_ratio, 2)                          AS freight_pct_of_revenue,
    round(100.0 * b.intra_se_freight_ratio, 2)                 AS benchmark_freight_pct,
    round(t.avg_delivery_days, 2)                              AS avg_delivery_days,
    round(b.intra_se_delivery_days, 2)                         AS benchmark_delivery_days,
    round(t.avg_delivery_days - b.intra_se_delivery_days, 2)   AS delivery_days_saved,

    -- Freight the customer would not pay if these lanes performed like an
    -- intra-region lane.
    round(t.freight_cost - t.item_revenue * b.intra_se_freight_ratio, 2)
                                                               AS freight_saving_period,
    round((t.freight_cost - t.item_revenue * b.intra_se_freight_ratio) * a.annualise, 2)
                                                               AS freight_saving_per_year,
    round(100.0 * (t.freight_cost - t.item_revenue * b.intra_se_freight_ratio)
          / t.freight_cost, 1)                                 AS pct_freight_removed
FROM target_lanes t, benchmark b, annual a
ORDER BY freight_saving_per_year DESC;
