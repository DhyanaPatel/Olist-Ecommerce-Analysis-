-- 22_padding_counterfactual — would quoting later dates actually fix lateness?
--
-- This is the query that kills the obvious recommendation, so it is worth being
-- direct about what it does.
--
-- Finding 2 shows that missing the promised date is catastrophic for the review
-- score. The tempting conclusion is to quote later dates and stop missing. This
-- query asks how many of the actual late orders each amount of extra padding
-- would have rescued, and what it would cost in quoted delivery time.
--
-- The cost side matters as much as the benefit. Padding is not free: it is
-- applied to EVERY order, including the ~74% that already arrive more than a
-- week early, and a slower quoted date is a worse offer at the point of sale.
-- The trade is therefore "N late orders rescued" against "one more day on the
-- quoted date for all 96,000 orders", and this query puts both sides in view.

WITH late_orders AS (
    SELECT days_vs_promise
    FROM fct_orders
    WHERE is_delivered AND is_late
),
totals AS (
    SELECT
        (SELECT count(*) FROM late_orders)                     AS total_late,
        (SELECT count(*) FROM fct_orders
          WHERE is_delivered AND is_late IS NOT NULL)          AS sla_orders,
        (SELECT avg(promised_days) FROM fct_orders WHERE is_delivered)
                                                               AS avg_promised_days
),
pads AS (SELECT unnest([1, 3, 5, 7, 14, 21]) AS extra_days)
SELECT
    p.extra_days                                               AS extra_promise_days,
    t.total_late,
    count(l.days_vs_promise) FILTER (WHERE l.days_vs_promise <= p.extra_days)
                                                               AS late_orders_rescued,
    round(100.0 * count(l.days_vs_promise)
          FILTER (WHERE l.days_vs_promise <= p.extra_days) / t.total_late, 1)
                                                               AS pct_of_lateness_fixed,
    t.total_late - count(l.days_vs_promise)
          FILTER (WHERE l.days_vs_promise <= p.extra_days)     AS still_late,
    round(100.0 * (t.total_late - count(l.days_vs_promise)
          FILTER (WHERE l.days_vs_promise <= p.extra_days)) / t.sla_orders, 2)
                                                               AS late_rate_after_pct,

    -- The price of the fix, on the other side of the ledger.
    round(t.avg_promised_days, 1)                              AS avg_promised_days_now,
    round(t.avg_promised_days + p.extra_days, 1)               AS avg_promised_days_after,
    -- Late orders rescued per extra day quoted to every customer. This ratio
    -- collapses fast, which is the whole argument.
    round(count(l.days_vs_promise)
          FILTER (WHERE l.days_vs_promise <= p.extra_days) * 1.0 / p.extra_days)
                                                               AS rescued_per_day_added
FROM pads p
CROSS JOIN totals t
LEFT JOIN late_orders l ON TRUE
GROUP BY p.extra_days, t.total_late, t.sla_orders, t.avg_promised_days
ORDER BY p.extra_days;
