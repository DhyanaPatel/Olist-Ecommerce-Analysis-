-- 11_detractor_value — what one bad first experience costs, in reais.
--
-- This query produces the conversion constant that every recommendation below is
-- priced with, so it is worth being explicit about what it does and does not
-- claim.
--
-- It measures: among first-time buyers observed for a full 180 days, the
-- difference in forward GMV between those who rated their first order 1-2 and
-- those who rated it 4-5.
--
-- It does NOT claim that the review caused the difference. Review score and
-- forward spend share obvious common causes. What it does give is the observed
-- value gap attached to a detractor, which is the right order-of-magnitude
-- anchor for sizing a fix — and it is deliberately the conservative choice,
-- because it ignores the effect of a public 1-star review on other buyers'
-- conversion, which this dataset cannot measure at all.
--
-- Also reported: the annualisation factor. The dataset covers ~25 months of
-- uneven ramp-up, so every recommendation is stated per year using the trailing
-- twelve stable months (2017-09 to 2018-08) as the run rate, never by dividing
-- the whole period by two.

WITH observable AS (
    SELECT
        o.customer_unique_id,
        o.purchase_date,
        o.review_score,
        o.is_detractor,
        o.order_gmv
    FROM fct_orders o
    WHERE o.is_first_order
      AND o.is_delivered
      AND o.has_review
      AND o.purchase_date <= (SELECT max(purchase_date) FROM fct_orders) - 180
),
forward AS (
    SELECT
        b.*,
        (SELECT coalesce(sum(r.order_gmv), 0)
         FROM fct_orders r
         WHERE r.customer_unique_id = b.customer_unique_id
           AND r.purchase_date >  b.purchase_date
           AND r.purchase_date <= b.purchase_date + 180)        AS forward_gmv,
        CASE WHEN EXISTS (
            SELECT 1 FROM fct_orders r
            WHERE r.customer_unique_id = b.customer_unique_id
              AND r.purchase_date >  b.purchase_date
              AND r.purchase_date <= b.purchase_date + 180
        ) THEN 1 ELSE 0 END                                     AS repeated
    FROM observable b
),
grouped AS (
    SELECT
        CASE WHEN review_score <= 2 THEN 'detractor (1-2)'
             WHEN review_score  = 3 THEN 'passive (3)'
             ELSE                        'satisfied (4-5)' END  AS cohort,
        count(*)                                                AS customers,
        avg(forward_gmv)                                        AS avg_forward_gmv,
        avg(repeated)                                           AS repeat_rate
    FROM forward
    GROUP BY 1
),
annualisation AS (
    SELECT
        count(*) FILTER (WHERE purchase_date >= DATE '2017-09-01'
                           AND purchase_date <  DATE '2018-09-01')      AS orders_ttm,
        count(*) FILTER (WHERE is_delivered)                            AS orders_total,
        sum(order_gmv) FILTER (WHERE purchase_date >= DATE '2017-09-01'
                                 AND purchase_date <  DATE '2018-09-01'
                                 AND is_delivered)                      AS gmv_ttm
    FROM fct_orders
    WHERE is_delivered
)
SELECT
    g.cohort,
    g.customers,
    round(100.0 * g.repeat_rate, 3)                            AS repeat_rate_180d_pct,
    round(g.avg_forward_gmv, 2)                                AS avg_forward_gmv,
    -- The headline constant: forward GMV lost per detractor, versus a satisfied
    -- customer in the same cohort window.
    round(max(g.avg_forward_gmv) OVER () - g.avg_forward_gmv, 2)
                                                               AS forward_gmv_gap,
    a.orders_ttm,
    a.orders_total,
    round(a.gmv_ttm, 2)                                        AS gmv_ttm,
    -- Multiply any whole-period count by this to state it as an annual run rate.
    round(a.orders_ttm * 1.0 / a.orders_total, 4)              AS annualisation_factor
FROM grouped g, annualisation a
ORDER BY g.cohort;
