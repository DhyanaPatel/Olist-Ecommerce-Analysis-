-- 05_review_vs_delivery — the dose-response curve between lateness and rating.
--
-- Question: how much rating damage does each day of lateness cost?
--
-- Bucketing days_vs_promise (delivered minus promised) rather than raw delivery
-- days is the important move. Customers do not experience "11 days"; they
-- experience "three days later than you told me". A 20-day delivery to Amazonas
-- that was promised in 25 days produces a happy customer; a 9-day delivery to
-- São Paulo promised in 6 does not.
--
-- The output is the evidence base for the delivery recommendation: it shows both
-- the size of the cliff and that it is a cliff rather than a slope.

WITH bucketed AS (
    SELECT
        CASE
            WHEN days_vs_promise <= -15 THEN '15+ days early'
            WHEN days_vs_promise <=  -8 THEN '8-14 days early'
            WHEN days_vs_promise <=  -4 THEN '4-7 days early'
            WHEN days_vs_promise <=  -1 THEN '1-3 days early'
            WHEN days_vs_promise  =   0 THEN 'On the promised day'
            WHEN days_vs_promise <=   3 THEN '1-3 days late'
            WHEN days_vs_promise <=   7 THEN '4-7 days late'
            WHEN days_vs_promise <=  14 THEN '8-14 days late'
            ELSE                             '15+ days late'
        END                                                    AS promise_bucket,
        CASE
            WHEN days_vs_promise <= -15 THEN 1 WHEN days_vs_promise <= -8 THEN 2
            WHEN days_vs_promise <=  -4 THEN 3 WHEN days_vs_promise <= -1 THEN 4
            WHEN days_vs_promise  =   0 THEN 5 WHEN days_vs_promise <=  3 THEN 6
            WHEN days_vs_promise <=   7 THEN 7 WHEN days_vs_promise <= 14 THEN 8
            ELSE 9
        END                                                    AS bucket_order,
        review_score,
        is_detractor,
        is_promoter,
        order_gmv
    FROM fct_orders
    WHERE is_delivered
      AND has_review
      AND days_vs_promise IS NOT NULL
)
SELECT
    promise_bucket,
    bucket_order,
    count(*)                                                   AS orders,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_orders,
    round(avg(review_score), 3)                                AS avg_review,
    round(100.0 * avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct,
    round(100.0 * avg(CASE WHEN is_promoter  THEN 1.0 ELSE 0.0 END), 2)
                                                               AS promoter_rate_pct,
    round(sum(order_gmv), 2)                                   AS gmv,
    -- Rating lost relative to the best-performing bucket, per order.
    round(max(avg(review_score)) OVER () - avg(review_score), 3)
                                                               AS review_points_lost
FROM bucketed
GROUP BY promise_bucket, bucket_order
ORDER BY bucket_order;
