-- 17_seller_geography — where supply actually sits.
--
-- This is the root cause behind most of the delivery findings. Demand is spread
-- across Brazil; supply is not. Every order placed outside the Southeast is
-- therefore a long-haul shipment by default, which is why freight and transit
-- time both roughly double the moment a parcel leaves its own region.
--
-- Reported on sellers who actually shipped something, not on the seller
-- registry, so dormant registrations do not flatter the coverage picture.

WITH active AS (
    SELECT DISTINCT seller_id FROM fct_order_items WHERE is_delivered
),
seller_region AS (
    SELECT
        s.region,
        count(*)                                               AS sellers
    FROM active a
    JOIN dim_seller s USING (seller_id)
    GROUP BY s.region
),
demand AS (
    SELECT
        c.region,
        count(*)                                               AS orders,
        sum(o.order_gmv)                                       AS gmv
    FROM fct_orders o
    JOIN dim_customer c USING (customer_id)
    WHERE o.is_delivered
    GROUP BY c.region
)
SELECT
    coalesce(s.region, d.region)                               AS region,
    coalesce(s.sellers, 0)                                     AS sellers,
    round(100.0 * coalesce(s.sellers, 0) / sum(coalesce(s.sellers, 0)) OVER (), 2)
                                                               AS pct_of_sellers,
    coalesce(d.orders, 0)                                      AS orders,
    round(100.0 * coalesce(d.orders, 0) / sum(coalesce(d.orders, 0)) OVER (), 2)
                                                               AS pct_of_demand,
    round(coalesce(d.gmv, 0), 2)                               AS gmv,
    -- Above 1.0 means the region hosts more supply than it consumes; below 1.0
    -- means it is served from somewhere else.
    round((coalesce(s.sellers, 0) * 1.0 / sum(coalesce(s.sellers, 0)) OVER ())
        / nullif(coalesce(d.orders, 0) * 1.0 / sum(coalesce(d.orders, 0)) OVER (), 0), 3)
                                                               AS supply_demand_ratio
FROM seller_region s
FULL OUTER JOIN demand d ON s.region = d.region
WHERE coalesce(s.region, d.region) <> 'Unknown'
ORDER BY pct_of_sellers DESC;
