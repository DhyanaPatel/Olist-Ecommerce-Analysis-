-- 19_deadline_dose_response — how bad does a missed deadline have to be?
--
-- Outcome by how many days past the contractual shipping_limit_date the seller
-- actually handed the parcel to the carrier.
--
-- A monotone dose-response is the strongest evidence available in observational
-- data that the deadline miss drives the outcome rather than merely accompanying
-- it: if some hidden third factor were responsible, there is no reason the
-- damage would scale with the size of the overshoot.
--
-- The practical read is in the first bucket. Most misses are by a single day,
-- and even those roughly double the late rate — so an enforcement programme does
-- not need to chase the extreme cases to be worth running.

WITH overshoot AS (
    SELECT
        o.order_id,
        o.is_late,
        o.is_detractor,
        o.review_score,
        o.order_gmv,
        max(CAST(s.handed_to_carrier_at AS DATE)
            - CAST(i.shipping_deadline AS DATE))               AS days_past_deadline
    FROM fct_orders o
    JOIN stg_order_items i USING (order_id)
    JOIN stg_orders      s USING (order_id)
    WHERE o.is_delivered
      AND o.any_deadline_missed
    GROUP BY o.order_id, o.is_late, o.is_detractor, o.review_score, o.order_gmv
)
SELECT
    CASE
        WHEN days_past_deadline <=  1 THEN '1 day'
        WHEN days_past_deadline <=  3 THEN '2-3 days'
        WHEN days_past_deadline <=  7 THEN '4-7 days'
        WHEN days_past_deadline <= 14 THEN '8-14 days'
        ELSE                               '15+ days'
    END                                                        AS overshoot_bucket,
    CASE
        WHEN days_past_deadline <=  1 THEN 1
        WHEN days_past_deadline <=  3 THEN 2
        WHEN days_past_deadline <=  7 THEN 3
        WHEN days_past_deadline <= 14 THEN 4
        ELSE 5
    END                                                        AS bucket_order,
    count(*)                                                   AS orders,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_missed,
    round(100.0 * avg(CASE WHEN is_late THEN 1.0 ELSE 0.0 END)
          FILTER (WHERE is_late IS NOT NULL), 2)               AS late_rate_pct,
    round(100.0 * avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct,
    round(avg(review_score), 3)                                AS avg_review,
    round(sum(order_gmv), 2)                                   AS gmv
FROM overshoot
GROUP BY overshoot_bucket, bucket_order
ORDER BY bucket_order;
