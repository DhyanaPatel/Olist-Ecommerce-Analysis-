-- 01_revenue_trend — monthly commercial trend on delivered orders.
--
-- Question: is the business growing, and is growth coming from more orders or
-- from bigger ones?
--
-- Two deliberate choices:
--   * Delivered orders only. An order that was cancelled or never shipped is not
--     revenue, and including it flatters the most recent months (which carry the
--     most in-flight orders) exactly where the trend line matters most.
--   * Months outside the stable window are still returned but flagged, so the
--     chart can grey them out instead of silently dropping data.

WITH monthly AS (
    SELECT
        d.year_month,
        d.month_start,
        bool_and(d.is_stable_window)                           AS is_stable,
        count(*)                                               AS orders,
        count(DISTINCT o.customer_unique_id)                   AS customers,
        sum(o.item_revenue)                                    AS item_revenue,
        sum(o.freight_value)                                   AS freight,
        sum(o.order_gmv)                                       AS gmv,
        sum(o.item_count)                                      AS units
    FROM fct_orders o
    JOIN dim_date d ON o.purchase_date = d.date_key
    WHERE o.is_delivered
    GROUP BY d.year_month, d.month_start
)
SELECT
    year_month,
    is_stable,
    orders,
    customers,
    units,
    round(gmv, 2)                                              AS gmv,
    round(item_revenue, 2)                                     AS item_revenue,
    round(freight, 2)                                          AS freight,
    round(gmv / orders, 2)                                     AS aov,
    round(units * 1.0 / orders, 3)                             AS units_per_order,
    round(100.0 * freight / nullif(item_revenue, 0), 2)        AS freight_pct_of_revenue,

    -- Month-on-month and year-on-year growth, computed in SQL so the dashboard
    -- displays a number it did not have to derive.
    round(100.0 * (gmv - lag(gmv) OVER (ORDER BY month_start))
          / nullif(lag(gmv) OVER (ORDER BY month_start), 0), 2)         AS gmv_mom_pct,
    round(100.0 * (gmv - lag(gmv, 12) OVER (ORDER BY month_start))
          / nullif(lag(gmv, 12) OVER (ORDER BY month_start), 0), 2)     AS gmv_yoy_pct,

    -- Three-month centred moving average, to read trend through the Black Friday
    -- spike that dominates November in this dataset.
    round(avg(gmv) OVER (ORDER BY month_start
                         ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING), 2)  AS gmv_ma3
FROM monthly
ORDER BY month_start;
