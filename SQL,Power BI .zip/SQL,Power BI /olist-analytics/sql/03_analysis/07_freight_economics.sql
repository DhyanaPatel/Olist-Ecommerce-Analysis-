-- 07_freight_economics — where shipping cost destroys the unit economics.
--
-- Question: which items cost more to ship than they are worth carrying?
--
-- Freight in this dataset is charged to the customer, but on a marketplace it is
-- the single largest driver of basket abandonment and of the "not worth it"
-- review. The band that matters is freight as a share of the item's own price:
-- a R$25 item with R$22 freight is a structurally bad offer no matter how good
-- the product is.
--
-- Item grain, delivered only. freight_ratio is capped at 5.0 upstream so a
-- handful of near-zero-price items cannot dominate a band average.

WITH banded AS (
    SELECT
        CASE
            WHEN freight_ratio IS NULL   THEN 'n/a'
            WHEN freight_ratio < 0.10    THEN '1. under 10%'
            WHEN freight_ratio < 0.20    THEN '2. 10-20%'
            WHEN freight_ratio < 0.35    THEN '3. 20-35%'
            WHEN freight_ratio < 0.50    THEN '4. 35-50%'
            WHEN freight_ratio < 1.00    THEN '5. 50-100%'
            ELSE                              '6. over 100%'
        END                                                    AS freight_band,
        i.item_revenue,
        i.freight_value,
        i.freight_ratio,
        p.weight_g,
        p.weight_band,
        o.review_score,
        o.is_detractor,
        o.delivery_days,
        i.order_id
    FROM fct_order_items i
    JOIN dim_product p USING (product_id)
    JOIN fct_orders  o USING (order_id)
    WHERE i.is_delivered
)
SELECT
    freight_band,
    count(*)                                                   AS units,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_units,
    round(sum(item_revenue), 2)                                AS item_revenue,
    round(100.0 * sum(item_revenue) / sum(sum(item_revenue)) OVER (), 2)
                                                               AS pct_of_revenue,
    round(sum(freight_value), 2)                               AS freight_cost,
    round(100.0 * sum(freight_value) / sum(sum(freight_value)) OVER (), 2)
                                                               AS pct_of_freight,
    round(avg(item_revenue), 2)                                AS avg_price,
    round(avg(freight_value), 2)                               AS avg_freight,
    round(avg(freight_ratio), 3)                               AS avg_freight_ratio,
    round(avg(weight_g))                                       AS avg_weight_g,
    round(avg(review_score), 3)                                AS avg_review,
    round(100.0 * avg(CASE WHEN is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct
FROM banded
WHERE freight_band <> 'n/a'
GROUP BY freight_band
ORDER BY freight_band;
