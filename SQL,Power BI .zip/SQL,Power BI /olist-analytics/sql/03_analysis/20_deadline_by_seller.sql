-- 20_deadline_by_seller — is missing the deadline a platform habit or a few sellers?
--
-- Sellers bucketed into deciles by their own deadline-miss rate. This decides
-- whether the fix is a policy change across thousands of accounts or a
-- conversation with a few dozen, which is the difference between a programme
-- that ships this quarter and one that does not.
--
-- Sellers with fewer than 20 delivered orders are excluded: with five orders a
-- miss rate is noise, and including them makes the worst decile look far worse
-- than any real, addressable population.
--
-- Orders are counted distinctly per seller, so a two-seller order is attributed
-- to both — each had its own deadline to meet.

WITH seller_rates AS (
    SELECT
        i.seller_id,
        count(DISTINCT i.order_id)                             AS orders,
        count(DISTINCT i.order_id) FILTER (WHERE i.missed_shipping_deadline)
                                                               AS missed
    FROM fct_order_items i
    WHERE i.is_delivered
    GROUP BY i.seller_id
    HAVING count(DISTINCT i.order_id) >= 20
),
ranked AS (
    SELECT
        *,
        missed * 1.0 / orders                                  AS miss_rate,
        -- seller_id tie-breaks so deciles are stable across runs.
        ntile(10) OVER (ORDER BY missed * 1.0 / orders, seller_id)
                                                               AS miss_decile
    FROM seller_rates
),
platform AS (
    -- Platform-wide denominators. The per-decile shares below are shares of the
    -- RANKED population (sellers with 20+ delivered orders), which is NOT the
    -- same as a share of the platform: small sellers are excluded from the
    -- ranking entirely, and they miss deadlines too. Both bases are returned so
    -- a written claim can name the one it is using.
    SELECT count(*) FILTER (WHERE any_deadline_missed)         AS platform_misses
    FROM fct_orders
    WHERE is_delivered AND any_deadline_missed IS NOT NULL
),
outcomes AS (
    -- Delivery outcomes for the orders each decile actually touched.
    SELECT
        r.miss_decile,
        count(DISTINCT o.order_id)                             AS distinct_orders,
        count(DISTINCT o.order_id) FILTER (WHERE o.any_deadline_missed)
                                                               AS distinct_misses,
        avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END)
            FILTER (WHERE o.is_late IS NOT NULL)               AS late_rate,
        avg(CASE WHEN o.is_detractor THEN 1.0 ELSE 0.0 END)    AS detractor_rate,
        avg(o.review_score)                                    AS avg_review,
        avg(o.seller_handover_days)                            AS avg_handover_days
    FROM ranked r
    JOIN fct_order_items i ON r.seller_id = i.seller_id AND i.is_delivered
    JOIN fct_orders      o ON i.order_id  = o.order_id
    GROUP BY r.miss_decile
)
SELECT
    r.miss_decile,
    count(*)                                                   AS sellers,
    sum(r.orders)                                              AS seller_orders,
    sum(r.missed)                                              AS deadline_misses,
    round(100.0 * sum(r.missed) / sum(r.orders), 2)            AS miss_rate_pct,
    round(100.0 * sum(r.missed) / sum(sum(r.missed)) OVER (), 2)
                                                               AS pct_of_ranked_misses,
    -- Platform basis: distinct orders this decile's sellers caused to miss, as a
    -- share of every deadline miss on the platform. This is the column to quote.
    max(o.distinct_misses)                                     AS platform_misses_caused,
    round(100.0 * max(o.distinct_misses) / max(p.platform_misses), 2)
                                                               AS pct_of_platform_misses,
    round(100.0 * max(o.late_rate), 2)                         AS late_rate_pct,
    round(100.0 * max(o.detractor_rate), 2)                    AS detractor_rate_pct,
    round(max(o.avg_review), 3)                                AS avg_review,
    round(max(o.avg_handover_days), 2)                         AS avg_handover_days
FROM ranked r
JOIN outcomes o USING (miss_decile)
CROSS JOIN platform p
GROUP BY r.miss_decile
ORDER BY r.miss_decile;
