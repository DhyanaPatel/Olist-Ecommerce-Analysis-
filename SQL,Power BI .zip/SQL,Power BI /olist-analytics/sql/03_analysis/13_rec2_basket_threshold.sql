-- 13_rec2_basket_threshold — sizing for Recommendation 2.
--
-- The finding: a sixth of everything Olist ships costs more than half the item's
-- price to deliver. These are cheap, heavy, single-item orders — the average unit
-- in this tail is R$30 of product carrying R$22 of freight. The customer is
-- paying a 74% shipping surcharge, and 85% of these orders are one-item baskets,
-- which is most of why the freight is so punishing per unit: there is nothing to
-- spread it over.
--
-- The proposal: a free-shipping threshold that makes the second item cheap to
-- add, applied to the affected SKUs.
--
-- Honest labelling of the assumption. Everything down to attach_rate is measured
-- from the data. The attach rate itself is NOT — it is the share of single-item
-- toxic-freight orders that would add a second item to clear the threshold. No
-- experiment in this dataset can identify it, so it is stated as an explicit
-- input and the output is given at 10%, 20% and 30% rather than as a single
-- number pretending to precision it does not have.

WITH toxic_items AS (
    SELECT
        i.order_id,
        i.item_revenue,
        i.freight_value,
        i.freight_ratio
    FROM fct_order_items i
    WHERE i.is_delivered
      AND i.freight_ratio >= 0.50
),
toxic_orders AS (
    SELECT
        o.order_id,
        o.item_count,
        o.item_revenue,
        o.freight_value,
        o.order_gmv
    FROM fct_orders o
    WHERE o.is_delivered
      AND o.order_id IN (SELECT order_id FROM toxic_items)
),
measured AS (
    SELECT
        (SELECT count(*) FROM toxic_items)                     AS toxic_units,
        (SELECT count(*) FROM fct_order_items WHERE is_delivered)
                                                               AS all_units,
        (SELECT round(sum(item_revenue), 2) FROM toxic_items)  AS toxic_item_revenue,
        (SELECT round(sum(freight_value), 2) FROM toxic_items) AS toxic_freight,
        (SELECT round(avg(item_revenue), 2) FROM toxic_items)  AS avg_toxic_price,
        (SELECT round(avg(freight_value), 2) FROM toxic_items) AS avg_toxic_freight,
        (SELECT count(*) FROM toxic_orders WHERE item_count = 1)
                                                               AS single_item_orders,
        (SELECT round(sum(order_gmv), 2) FROM toxic_orders WHERE item_count = 1)
                                                               AS single_item_gmv,
        (SELECT count(*) FROM toxic_orders)                    AS toxic_orders,
        (SELECT round(100.0 * count(*) FILTER (WHERE item_count = 1) / count(*), 2)
         FROM toxic_orders)                                    AS single_item_share_pct,
        (SELECT count(*) FROM fct_orders WHERE is_delivered)   AS all_orders,
        (SELECT count(*) FILTER (WHERE purchase_date >= DATE '2017-09-01'
                                   AND purchase_date <  DATE '2018-09-01') * 1.0
              / count(*) FROM fct_orders WHERE is_delivered)   AS annualise
),
scenarios AS (
    SELECT unnest([0.10, 0.20, 0.30]) AS attach_rate
)
SELECT
    s.attach_rate,
    m.toxic_units,
    round(100.0 * m.toxic_units / m.all_units, 2)              AS pct_of_all_units,
    m.toxic_item_revenue,
    m.toxic_freight,
    round(100.0 * m.toxic_freight / m.toxic_item_revenue, 1)   AS freight_pct_of_price,
    m.avg_toxic_price,
    m.avg_toxic_freight,
    m.toxic_orders,
    m.single_item_orders,
    m.single_item_share_pct,
    m.single_item_gmv,

    -- Orders that add a second item under the threshold.
    round(m.single_item_orders * s.attach_rate)                AS orders_converted,
    -- Each adds roughly one more unit at the tail's own average price.
    round(m.single_item_orders * s.attach_rate * m.avg_toxic_price, 2)
                                                               AS incremental_item_revenue_period,
    round(m.single_item_orders * s.attach_rate * m.avg_toxic_price * m.annualise, 2)
                                                               AS incremental_item_revenue_per_year,
    -- Freight is charged once per parcel, so the second unit ships free: the
    -- freight burden on the converted baskets halves.
    round(100.0 * m.avg_toxic_freight / (2 * m.avg_toxic_price), 1)
                                                               AS freight_pct_after_conversion
FROM measured m, scenarios s
ORDER BY s.attach_rate;
