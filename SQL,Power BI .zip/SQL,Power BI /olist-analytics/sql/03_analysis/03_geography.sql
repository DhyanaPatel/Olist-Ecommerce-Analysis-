-- 03_geography — state-level demand and service quality.
--
-- Question: where does the money come from, and where is the service worst?
-- These are almost inverse in this dataset, which is the whole point: the
-- concentration of sellers in the Southeast makes the Southeast fast and cheap
-- to serve and everywhere else slow and expensive.

SELECT
    c.state,
    c.region,
    count(*)                                                   AS orders,
    count(DISTINCT c.customer_unique_id)                       AS customers,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_orders,
    round(sum(o.order_gmv), 2)                                 AS gmv,
    round(100.0 * sum(o.order_gmv) / sum(sum(o.order_gmv)) OVER (), 2)
                                                               AS pct_of_gmv,
    round(avg(o.order_gmv), 2)                                 AS aov,
    round(avg(o.freight_value), 2)                             AS avg_freight,
    round(100.0 * sum(o.freight_value) / nullif(sum(o.item_revenue), 0), 2)
                                                               AS freight_pct_of_revenue,

    round(avg(o.delivery_days), 2)                             AS avg_delivery_days,
    round(quantile_cont(o.delivery_days, 0.90), 1)             AS p90_delivery_days,
    round(avg(o.promised_days), 2)                             AS avg_promised_days,
    -- How much slack is built into the promise, on average.
    round(avg(o.promised_days) - avg(o.delivery_days), 2)      AS avg_promise_slack,
    round(100.0 * avg(CASE WHEN o.is_late THEN 1.0 ELSE 0.0 END) FILTER (WHERE o.is_late IS NOT NULL), 2)
                                                               AS late_rate_pct,
    round(avg(o.review_score), 3)                              AS avg_review,
    round(100.0 * avg(CASE WHEN o.is_detractor THEN 1.0 ELSE 0.0 END), 2)
                                                               AS detractor_rate_pct
FROM fct_orders o
JOIN dim_customer c USING (customer_id)
WHERE o.is_delivered
GROUP BY c.state, c.region
ORDER BY gmv DESC;
