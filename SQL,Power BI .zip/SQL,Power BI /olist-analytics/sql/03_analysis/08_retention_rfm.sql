-- 08_retention_rfm — repeat behaviour and RFM segmentation at person grain.
--
-- Question: does anyone come back, and is the repeat population worth chasing?
--
-- Everything here keys on customer_unique_id. Using customer_id instead returns
-- a repeat rate of exactly zero, because Olist mints a fresh customer_id per
-- order — the most common false finding published from this dataset.
--
-- Recency is measured against the last purchase date in the data, not today's
-- date, because the dataset ends in 2018.

WITH person AS (
    SELECT
        customer_unique_id,
        count(*)                                               AS frequency,
        sum(order_gmv)                                         AS monetary,
        max(purchase_date)                                     AS last_purchase,
        min(purchase_date)                                     AS first_purchase,
        avg(review_score)                                      AS avg_review,
        max(CASE WHEN is_detractor THEN 1 ELSE 0 END)          AS ever_detractor
    FROM fct_orders
    WHERE is_delivered
    GROUP BY customer_unique_id
),
scored AS (
    SELECT
        p.*,
        (SELECT max(purchase_date) FROM fct_orders) - p.last_purchase AS recency_days,
        -- customer_unique_id breaks ties so the quintile boundaries — and
        -- therefore the segment counts — are identical on every run.
        ntile(5) OVER (ORDER BY (SELECT max(purchase_date) FROM fct_orders)
                                - p.last_purchase DESC,
                                p.customer_unique_id)          AS r_score,
        ntile(5) OVER (ORDER BY p.frequency, p.monetary,
                                p.customer_unique_id)          AS f_score,
        ntile(5) OVER (ORDER BY p.monetary,
                                p.customer_unique_id)          AS m_score
    FROM person p
),
segmented AS (
    SELECT
        *,
        CASE
            WHEN frequency >= 2 AND r_score >= 4 AND m_score >= 4 THEN 'Champions'
            WHEN frequency >= 2 AND r_score >= 3                  THEN 'Loyal'
            WHEN frequency >= 2                                   THEN 'Lapsed repeat'
            WHEN r_score >= 4 AND m_score >= 4                    THEN 'Promising one-timer'
            WHEN r_score >= 4                                     THEN 'Recent one-timer'
            WHEN m_score >= 4                                     THEN 'Dormant high-value'
            ELSE                                                       'Dormant'
        END                                                    AS segment
    FROM scored
)
SELECT
    segment,
    count(*)                                                   AS customers,
    round(100.0 * count(*) / sum(count(*)) OVER (), 2)         AS pct_of_customers,
    sum(frequency)                                             AS orders,
    round(sum(monetary), 2)                                    AS gmv,
    round(100.0 * sum(monetary) / sum(sum(monetary)) OVER (), 2)
                                                               AS pct_of_gmv,
    round(avg(frequency), 3)                                   AS avg_orders,
    round(avg(monetary), 2)                                    AS avg_gmv,
    round(avg(monetary / frequency), 2)                        AS avg_order_value,
    round(avg(recency_days), 1)                                AS avg_recency_days,
    round(avg(avg_review), 3)                                  AS avg_review,
    round(100.0 * avg(ever_detractor), 2)                      AS pct_ever_detractor
FROM segmented
GROUP BY segment
ORDER BY gmv DESC;
