-- 00_compat.sql — DuckDB shims for PostgreSQL built-ins.
--
-- The analysis SQL in this project is written in portable PostgreSQL: CTEs,
-- window functions, FILTER clauses, NTILE, date_trunc, EXTRACT, and date
-- subtraction all behave identically on both engines. Two things do not, and
-- they are shimmed here so the query files stay dialect-clean:
--
--   initcap()  — PostgreSQL built-in, absent from DuckDB.
--   generate_series over dates — PostgreSQL returns rows, DuckDB returns a list
--                                that needs UNNEST. Handled inline in dim_date,
--                                which is the only place it appears.
--
-- Running this project on PostgreSQL instead: skip this file, and change the
-- one UNNEST in dim_date.sql to a plain FROM generate_series(...).

CREATE OR REPLACE MACRO initcap(s) AS
    CASE WHEN s IS NULL THEN NULL
         ELSE upper(substr(s, 1, 1)) || lower(substr(s, 2))
    END;
