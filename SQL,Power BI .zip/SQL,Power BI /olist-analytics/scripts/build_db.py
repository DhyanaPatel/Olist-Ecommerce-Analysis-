"""
build_db.py — load the raw Olist CSVs into a typed DuckDB database.

Usage:
    python scripts/build_db.py [--raw data/raw] [--db olist.duckdb]

Reads the nine Kaggle CSVs, applies explicit types (dates as TIMESTAMP, money as
DOUBLE), then runs the staging + mart SQL to build the analysis star schema.
Prints a data-quality report so nothing is silently dropped.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]

# Kaggle filename -> raw table name
FILES = {
    "olist_customers_dataset.csv": "raw_customers",
    "olist_geolocation_dataset.csv": "raw_geolocation",
    "olist_order_items_dataset.csv": "raw_order_items",
    "olist_order_payments_dataset.csv": "raw_order_payments",
    "olist_order_reviews_dataset.csv": "raw_order_reviews",
    "olist_orders_dataset.csv": "raw_orders",
    "olist_products_dataset.csv": "raw_products",
    "olist_sellers_dataset.csv": "raw_sellers",
    "product_category_name_translation.csv": "raw_category_translation",
}

# Columns that must be read as TIMESTAMP rather than sniffed.
TIMESTAMP_COLS = {
    "raw_orders": [
        "order_purchase_timestamp",
        "order_approved_at",
        "order_delivered_carrier_date",
        "order_delivered_customer_date",
        "order_estimated_delivery_date",
    ],
    "raw_order_items": ["shipping_limit_date"],
    "raw_order_reviews": ["review_creation_date", "review_answer_timestamp"],
}

SQL_STEPS = [
    "sql/00_compat.sql",
    "sql/01_staging/stg_orders.sql",
    "sql/01_staging/stg_order_items.sql",
    "sql/01_staging/stg_payments.sql",
    "sql/01_staging/stg_reviews.sql",
    "sql/01_staging/stg_products.sql",
    "sql/01_staging/stg_customers.sql",
    "sql/01_staging/stg_sellers.sql",
    "sql/02_marts/dim_date.sql",
    "sql/02_marts/dim_product.sql",
    "sql/02_marts/dim_customer.sql",
    "sql/02_marts/dim_seller.sql",
    "sql/02_marts/fct_order_items.sql",
    "sql/02_marts/fct_orders.sql",
]


def load_raw(con: duckdb.DuckDBPyConnection, raw_dir: Path) -> None:
    missing = [f for f in FILES if not (raw_dir / f).exists()]
    if missing:
        sys.exit(
            "Missing CSVs in {}:\n  - {}\n\nDownload 'Brazilian E-Commerce Public "
            "Dataset by Olist' from Kaggle and unzip it there.".format(
                raw_dir, "\n  - ".join(missing)
            )
        )

    for fname, table in FILES.items():
        path = (raw_dir / fname).as_posix()
        ts = TIMESTAMP_COLS.get(table)
        if ts:
            types = ", ".join(f"'{c}': 'TIMESTAMP'" for c in ts)
            reader = f"read_csv('{path}', header=true, types={{{types}}})"
        else:
            reader = f"read_csv_auto('{path}', header=true)"
        con.execute(f"CREATE OR REPLACE TABLE {table} AS SELECT * FROM {reader}")
        n = con.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
        print(f"  loaded {table:<26} {n:>9,} rows")


def run_sql_steps(con: duckdb.DuckDBPyConnection) -> None:
    for rel in SQL_STEPS:
        path = ROOT / rel
        if not path.exists():
            sys.exit(f"Missing SQL file: {rel}")
        con.execute(path.read_text())
        print(f"  built {path.stem}")


def quality_report(con: duckdb.DuckDBPyConnection) -> None:
    checks = [
        (
            "orders: total | delivered | cancelled",
            "SELECT count(*), count(*) FILTER (WHERE order_status='delivered'), "
            "count(*) FILTER (WHERE order_status='canceled') FROM raw_orders",
        ),
        (
            "delivered orders missing delivery date",
            "SELECT count(*) FROM raw_orders WHERE order_status='delivered' "
            "AND order_delivered_customer_date IS NULL",
        ),
        (
            "orders with no order_items row",
            "SELECT count(*) FROM raw_orders o LEFT JOIN raw_order_items i "
            "USING (order_id) WHERE i.order_id IS NULL",
        ),
        (
            "items with unknown product category",
            "SELECT count(*) FROM raw_order_items i JOIN raw_products p USING (product_id) "
            "WHERE p.product_category_name IS NULL",
        ),
        (
            "orders carrying more than one review",
            "SELECT count(*) FROM (SELECT order_id FROM raw_order_reviews "
            "GROUP BY 1 HAVING count(*) > 1)",
        ),
        (
            "purchase date range",
            "SELECT min(order_purchase_timestamp)::DATE, max(order_purchase_timestamp)::DATE "
            "FROM raw_orders",
        ),
        (
            "fct_order_items: rows | distinct orders",
            "SELECT count(*), count(DISTINCT order_id) FROM fct_order_items",
        ),
        (
            "payments R$ vs item+freight R$ (matched orders)",
            """SELECT round(sum(p.paid)) , round(sum(f.gmv)) FROM
               (SELECT order_id, sum(payment_value) paid FROM raw_order_payments GROUP BY 1) p
               JOIN (SELECT order_id, sum(item_revenue + freight_value) gmv
                     FROM fct_order_items GROUP BY 1) f USING (order_id)""",
        ),
    ]
    print("\nData-quality report")
    print("-" * 70)
    for label, q in checks:
        vals = con.execute(q).fetchone()
        pretty = " | ".join(
            f"{v:,.0f}" if isinstance(v, (int, float)) else str(v) for v in vals
        )
        print(f"  {label:<45} {pretty}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=str(ROOT / "data" / "raw"))
    ap.add_argument("--db", default=str(ROOT / "olist.duckdb"))
    args = ap.parse_args()

    db_path = Path(args.db)
    if db_path.exists():
        db_path.unlink()

    con = duckdb.connect(str(db_path))
    print(f"Loading raw CSVs from {args.raw}")
    load_raw(con, Path(args.raw))
    print("\nBuilding staging + mart layer")
    run_sql_steps(con)
    quality_report(con)
    con.close()
    print(f"\nDatabase written to {db_path}")


if __name__ == "__main__":
    main()
