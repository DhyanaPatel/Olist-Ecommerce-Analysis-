"""
export_marts.py — write the six mart tables to CSV for Power BI.

Usage:
    python scripts/export_marts.py [--db olist.duckdb] [--out output/marts]

Use this when connecting Power BI by folder rather than by DuckDB ODBC. The CSVs
are the same tables the SQL layer built, so the .pbix is never re-deriving logic
that already exists in SQL.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]

MARTS = [
    "fct_orders",
    "fct_order_items",
    "dim_date",
    "dim_customer",
    "dim_product",
    "dim_seller",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=str(ROOT / "olist.duckdb"))
    ap.add_argument("--out", default=str(ROOT / "output" / "marts"))
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        raise SystemExit(f"No database at {db}. Run scripts/build_db.py first.")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(str(db), read_only=True)
    for table in MARTS:
        target = (out / f"{table}.csv").as_posix()
        con.execute(f"COPY {table} TO '{target}' (HEADER, DELIMITER ',')")
        rows = con.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
        mb = (out / f"{table}.csv").stat().st_size / 1_048_576
        print(f"  {table:<18} {rows:>8,} rows   {mb:6.1f} MB")
    con.close()
    print(f"\nMarts written to {out}")


if __name__ == "__main__":
    main()
