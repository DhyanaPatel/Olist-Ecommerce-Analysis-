"""
make_sample_data.py — generate an Olist-shaped sample dataset.

The real data is the Kaggle "Brazilian E-Commerce Public Dataset by Olist",
which cannot be redistributed here. This script writes the same nine CSVs with
the same column names and dtypes, calibrated to the published aggregates of the
real dataset (order count, delivered share, AOV, freight share, review mix,
state distribution, delivery-time distribution) so the whole pipeline can be
built, run and reviewed without a Kaggle account.

    python scripts/make_sample_data.py --out data/sample

The SQL is identical for both sources. To run on the real data, unzip the Kaggle
files into data/raw and point build_db.py there.

Calibration targets (real Olist, for reference):
    orders 99,441 | items 112,650 | delivered 97.0% | AOV R$137
    freight 17.5% of item revenue | mean review 4.09 | late 6.8%
    on-time mean review 4.29 | late mean review 2.25 | SP share 42%
"""

from __future__ import annotations

import argparse
import uuid
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(20180901)

N_ORDERS = 99_441
N_SELLERS = 3_095
N_PRODUCTS = 32_951

START = datetime(2016, 9, 4)
END = datetime(2018, 10, 17)

# state -> (customer share, seller share, extra transit days vs SP)
STATES = {
    "SP": (0.4198, 0.7100, 0.0), "RJ": (0.1291, 0.0560, 3.2),
    "MG": (0.1170, 0.0800, 2.4), "RS": (0.0546, 0.0420, 4.6),
    "PR": (0.0503, 0.0420, 3.4), "SC": (0.0365, 0.0620, 4.0),
    "BA": (0.0338, 0.0060, 8.2), "DF": (0.0217, 0.0100, 6.0),
    "ES": (0.0205, 0.0080, 4.2), "GO": (0.0204, 0.0130, 6.4),
    "PE": (0.0167, 0.0030, 10.1), "CE": (0.0134, 0.0040, 11.4),
    "PA": (0.0098, 0.0010, 15.2), "MT": (0.0091, 0.0030, 8.8),
    "MA": (0.0075, 0.0005, 13.6), "MS": (0.0072, 0.0020, 7.1),
    "PB": (0.0054, 0.0010, 12.0), "PI": (0.0050, 0.0005, 12.4),
    "RN": (0.0049, 0.0010, 12.2), "AL": (0.0041, 0.0010, 12.6),
    "SE": (0.0035, 0.0005, 11.8), "TO": (0.0028, 0.0005, 10.9),
    "RO": (0.0025, 0.0005, 14.4), "AM": (0.0015, 0.0005, 18.8),
    "AC": (0.0008, 0.0002, 19.6), "AP": (0.0007, 0.0002, 20.1),
    "RR": (0.0005, 0.0002, 21.0),
}

CATEGORIES = {
    # category_pt: (share of items, price mean, price sd, weight_g mean)
    "cama_mesa_banho":          (0.098, 93,  70,  2100),
    "beleza_saude":             (0.087, 130, 110, 700),
    "esporte_lazer":            (0.079, 114, 95,  1900),
    "moveis_decoracao":         (0.074, 87,  92,  4300),
    "informatica_acessorios":   (0.070, 116, 130, 900),
    "utilidades_domesticas":    (0.061, 91,  80,  2300),
    "relogios_presentes":       (0.052, 201, 160, 500),
    "telefonia":                (0.041, 71,  62,  400),
    "ferramentas_jardim":       (0.038, 111, 120, 5200),
    "automotivo":               (0.037, 140, 130, 2400),
    "brinquedos":               (0.035, 117, 100, 1400),
    "cool_stuff":               (0.033, 167, 140, 1600),
    "perfumaria":               (0.030, 128, 90,  400),
    "bebes":                    (0.027, 143, 120, 2600),
    "eletronicos":              (0.024, 58,  55,  700),
    "papelaria":                (0.023, 78,  70,  1100),
    "fashion_bolsas_e_acessorios": (0.019, 105, 95, 600),
    "pet_shop":                 (0.018, 100, 90,  3400),
    "moveis_escritorio":        (0.016, 220, 220, 9800),
    "consoles_games":           (0.011, 138, 140, 1100),
    "construcao_ferramentas_construcao": (0.010, 180, 170, 7600),
    "casa_construcao":          (0.009, 160, 150, 6800),
    "alimentos":                (0.008, 60,  45,  1500),
    "livros_interesse_geral":   (0.007, 62,  40,  800),
    "instrumentos_musicais":    (0.006, 260, 230, 3100),
    "eletrodomesticos":         (0.006, 290, 260, 11000),
    "climatizacao":             (0.005, 320, 300, 12500),
    "artes":                    (0.004, 95,  85,  1300),
    "market_place":             (0.003, 130, 120, 1500),
}

CATEGORY_EN = {
    "cama_mesa_banho": "bed_bath_table", "beleza_saude": "health_beauty",
    "esporte_lazer": "sports_leisure", "moveis_decoracao": "furniture_decor",
    "informatica_acessorios": "computers_accessories",
    "utilidades_domesticas": "housewares", "relogios_presentes": "watches_gifts",
    "telefonia": "telephony", "ferramentas_jardim": "garden_tools",
    "automotivo": "auto", "brinquedos": "toys", "cool_stuff": "cool_stuff",
    "perfumaria": "perfumery", "bebes": "baby", "eletronicos": "electronics",
    "papelaria": "stationery",
    "fashion_bolsas_e_acessorios": "fashion_bags_accessories",
    "pet_shop": "pet_shop", "moveis_escritorio": "office_furniture",
    "consoles_games": "consoles_games",
    "construcao_ferramentas_construcao": "construction_tools_construction",
    "casa_construcao": "home_construction", "alimentos": "food",
    "livros_interesse_geral": "books_general_interest",
    "instrumentos_musicais": "musical_instruments",
    "eletrodomesticos": "home_appliances", "climatizacao": "air_conditioning",
    "artes": "art", "market_place": "market_place",
}


def hexid(n: int) -> np.ndarray:
    """n distinct 32-char hex ids, matching Olist's id format."""
    return np.array([uuid.UUID(int=int(x)).hex for x in
                     RNG.choice(2**62, size=n, replace=False)])


def pick(keys, probs, n):
    p = np.asarray(probs, dtype=float)
    return RNG.choice(list(keys), size=n, p=p / p.sum())


def build(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    st_names = list(STATES)
    cust_p = [STATES[s][0] for s in st_names]
    sell_p = [STATES[s][1] for s in st_names]
    dist = {s: STATES[s][2] for s in st_names}

    # ---------- sellers ----------
    seller_ids = hexid(N_SELLERS)
    seller_state = pick(st_names, sell_p, N_SELLERS)
    sellers = pd.DataFrame({
        "seller_id": seller_ids,
        "seller_zip_code_prefix": RNG.integers(1000, 99999, N_SELLERS),
        "seller_city": ["city_" + s.lower() for s in seller_state],
        "seller_state": seller_state,
    })
    # Seller reliability: a long tail of sellers who are chronically slow to ship.
    seller_lag = RNG.gamma(1.6, 1.05, N_SELLERS)

    # ---------- products ----------
    prod_ids = hexid(N_PRODUCTS)
    cat_pt = pick(CATEGORIES.keys(), [c[0] for c in CATEGORIES.values()], N_PRODUCTS)
    wmean = np.array([CATEGORIES[c][3] for c in cat_pt], dtype=float)
    weight = np.clip(RNG.lognormal(np.log(wmean), 0.75), 50, 40000).round()
    side = np.clip((weight ** 0.33) * RNG.lognormal(0.55, 0.30, N_PRODUCTS), 7, 105)
    products = pd.DataFrame({
        "product_id": prod_ids,
        "product_category_name": cat_pt,
        "product_name_lenght": RNG.integers(20, 70, N_PRODUCTS),
        "product_description_lenght": RNG.integers(100, 3800, N_PRODUCTS),
        "product_photos_qty": RNG.integers(1, 8, N_PRODUCTS),
        "product_weight_g": weight,
        "product_length_cm": side.round(),
        "product_height_cm": (side * RNG.uniform(0.3, 0.9, N_PRODUCTS)).round(),
        "product_width_cm": (side * RNG.uniform(0.4, 1.0, N_PRODUCTS)).round(),
    })
    # ~1.8% of products have no category in the real file.
    products.loc[RNG.random(N_PRODUCTS) < 0.018, "product_category_name"] = None

    # ---------- order timing ----------
    # Volume ramps steeply through 2017 then plateaus, as in the real series.
    # Orders are generated in chronological order, which the repeat-purchase
    # linkage below relies on.
    span = (END - START).days
    t = np.sort(RNG.beta(2.35, 1.5, N_ORDERS)) * span
    purchased = np.array([START + timedelta(days=float(d),
                                            hours=float(h), minutes=float(m))
                          for d, h, m in zip(t,
                                             RNG.integers(8, 23, N_ORDERS),
                                             RNG.integers(0, 60, N_ORDERS))])

    # ---------- customers and repeat linkage ----------
    # 99,441 customer_id rows map onto ~96,000 people: ~3.4% order more than once.
    #
    # Repeats are linked in time rather than at random. A second order is
    # attached to a first order that happened 15-200 days earlier, because real
    # repeat purchases cluster within a few months. Linking at random spreads the
    # gap uniformly across two years and makes any repeat-window analysis
    # meaningless.
    #
    # The satisfaction filter is applied further down, once review scores exist:
    # a repeat link whose first order was rated badly is broken, which is the
    # mechanism that makes review score predict repeat purchase.
    n_repeat = 3_345
    owner = np.arange(N_ORDERS)                 # provisional: everyone distinct
    t_days = t.copy()
    # Candidate second orders, drawn from the part of the window that has enough
    # history behind it.
    eligible = np.flatnonzero(t_days > 200)
    second_idx = np.sort(RNG.choice(eligible, size=n_repeat, replace=False))
    taken = np.zeros(N_ORDERS, dtype=bool)
    taken[second_idx] = True
    for j in second_idx:
        lo = np.searchsorted(t_days, t_days[j] - 200, side="left")
        hi = np.searchsorted(t_days, t_days[j] - 15, side="right")
        if hi <= lo:
            continue
        for _ in range(12):                     # a few tries to find a free first order
            i = int(RNG.integers(lo, hi))
            if not taken[i]:
                owner[j] = owner[i]
                taken[i] = True
                break

    people_state_by_order = pick(st_names, cust_p, N_ORDERS)
    cust_state = people_state_by_order[owner]   # state follows the person
    cust_ids = hexid(N_ORDERS)

    status = np.where(RNG.random(N_ORDERS) < 0.9702, "delivered",
             np.where(RNG.random(N_ORDERS) < 0.21, "canceled",
             np.where(RNG.random(N_ORDERS) < 0.5, "shipped", "unavailable")))
    # The last three weeks are still in flight.
    tail = purchased > (END - timedelta(days=21))
    status = np.where(tail & (RNG.random(N_ORDERS) < 0.55), "shipped", status)

    # ---------- order items ----------
    # 1.14 items per order on average.
    n_items = RNG.choice([1, 2, 3, 4, 5], N_ORDERS,
                         p=[0.885, 0.084, 0.019, 0.008, 0.004])
    order_ids = hexid(N_ORDERS)
    oi_order = np.repeat(order_ids, n_items)
    oi_seq = np.concatenate([np.arange(1, k + 1) for k in n_items])
    total_items = int(n_items.sum())

    prod_idx = RNG.choice(N_PRODUCTS, total_items,
                          p=np.full(N_PRODUCTS, 1 / N_PRODUCTS))
    sell_idx = RNG.choice(N_SELLERS, total_items)

    pmean = np.array([CATEGORIES[c][1] if c else 110
                      for c in products["product_category_name"].values[prod_idx]])
    price = np.clip(RNG.lognormal(np.log(pmean * 0.78), 0.72), 3, 6735).round(2)

    # Freight is driven by dimensional weight and by distance, not by price.
    o_state = np.repeat(cust_state, n_items)
    s_state = seller_state[sell_idx]
    km = np.array([abs(dist[a] - dist[b]) for a, b in zip(o_state, s_state)])
    dim_kg = np.maximum(products["product_weight_g"].values[prod_idx] / 1000,
                        (products["product_length_cm"].values[prod_idx] *
                         products["product_height_cm"].values[prod_idx] *
                         products["product_width_cm"].values[prod_idx]) / 6000)
    freight = np.clip(11.5 + 2.10 * dim_kg + 1.05 * km +
                      RNG.normal(0, 2.6, total_items), 0, 410).round(2)

    ship_limit = np.repeat(purchased, n_items) + np.array(
        [timedelta(days=float(d)) for d in RNG.uniform(2, 7, total_items)])

    order_items = pd.DataFrame({
        "order_id": oi_order,
        "order_item_id": oi_seq,
        "product_id": prod_ids[prod_idx],
        "seller_id": seller_ids[sell_idx],
        "shipping_limit_date": ship_limit,
        "price": price,
        "freight_value": freight,
    })

    # ---------- delivery clock ----------
    o_km = np.array([dist[s] for s in cust_state])
    approval = RNG.gamma(1.1, 0.34, N_ORDERS)                       # ~0.4d
    # Seller handover: the biggest controllable slice, and heavily seller-driven.
    first_seller = pd.Series(sell_idx).groupby(pd.Series(oi_order)).first()
    first_seller = first_seller.reindex(order_ids).values
    handover = RNG.gamma(2.1, 1.20, N_ORDERS) + seller_lag[first_seller]
    # A ~5% tail of orders hits a real logistics failure (lost at the hub,
    # reattempted delivery, carrier strike). This tail is what actually produces
    # the detractor population, so it has to be modelled, not smoothed away.
    shock = np.where(RNG.random(N_ORDERS) < 0.06, RNG.exponential(14, N_ORDERS), 0)
    transit = np.clip(RNG.gamma(2.5, 1.70, N_ORDERS) + 0.80 * o_km + shock, 0.5, None)

    approved = purchased + np.array([timedelta(days=float(d)) for d in approval])
    to_carrier = approved + np.array([timedelta(days=float(d)) for d in handover])
    delivered = to_carrier + np.array([timedelta(days=float(d)) for d in transit])

    # The promise: padded, and padded harder for distant states.
    promise_days = np.clip(RNG.normal(18.6 + 1.15 * o_km, 4.6), 3, 60)
    promised = purchased + np.array([timedelta(days=float(round(d)))
                                     for d in promise_days])

    orders = pd.DataFrame({
        "order_id": order_ids,
        "customer_id": cust_ids,
        "order_status": status,
        "order_purchase_timestamp": purchased,
        "order_approved_at": approved,
        "order_delivered_carrier_date": to_carrier,
        "order_delivered_customer_date": delivered,
        "order_estimated_delivery_date": promised,
    })
    nd = orders["order_status"] != "delivered"
    orders.loc[nd, "order_delivered_customer_date"] = pd.NaT
    orders.loc[orders["order_status"].isin(["canceled", "unavailable"]),
               "order_delivered_carrier_date"] = pd.NaT
    # ~0.16% of delivered orders are missing the delivery timestamp in the real file.
    orders.loc[orders.sample(frac=0.0016, random_state=7).index,
               "order_delivered_customer_date"] = pd.NaT

    # ---------- payments ----------
    order_value = (order_items.groupby("order_id")[["price", "freight_value"]]
                   .sum().sum(axis=1).reindex(order_ids).values)
    ptype = RNG.choice(["credit_card", "boleto", "voucher", "debit_card"],
                       N_ORDERS, p=[0.7395, 0.1904, 0.0554, 0.0147])
    inst_p = np.array([.42,.15,.11,.07,.06,.05,.03,.035,.02,.03,.005,.015])
    inst = np.where(ptype == "credit_card",
                    RNG.choice(np.arange(1, 13), N_ORDERS, p=inst_p / inst_p.sum()),
                    1)
    payments = pd.DataFrame({
        "order_id": order_ids,
        "payment_sequential": 1,
        "payment_type": ptype,
        "payment_installments": inst,
        "payment_value": np.round(order_value, 2),
    })

    # ---------- reviews ----------
    # Two independent channels produce a bad review, which is why the real Olist
    # score distribution is J-shaped rather than merely left-skewed:
    #
    #   1. Lateness. Continuous, and the further past the promise, the worse.
    #   2. Fulfilment failure. Wrong item, damaged, never arrived, seller
    #      unresponsive. Fires regardless of timing and lands almost entirely on
    #      1-2 stars. Correlated with the seller's own reliability, so slow
    #      sellers are also the ones generating quality complaints.
    #
    # Modelling only channel 1 would make lateness look like the whole story and
    # would overstate what a logistics fix can recover.
    late_by = (orders["order_delivered_customer_date"] -
               orders["order_estimated_delivery_date"]).dt.days.fillna(0).values
    base = np.where(late_by > 0,
                    2.25 - 0.050 * np.clip(late_by, 0, 30),
                    4.97 + 0.006 * np.clip(-late_by, 0, 20))
    base = np.where(orders["order_status"].values == "canceled", 1.6, base)
    score = np.clip(np.round(base + RNG.normal(0, 1.15, N_ORDERS)), 1, 5).astype(int)

    lag_pct = seller_lag[first_seller] / seller_lag.max()
    fail_p = np.clip(0.085 + 0.160 * lag_pct, 0, 0.40)
    failed = RNG.random(N_ORDERS) < fail_p
    score = np.where(failed,
                     RNG.choice([1, 2], N_ORDERS, p=[0.78, 0.22]),
                     score).astype(int)

    has_review = RNG.random(N_ORDERS) < 0.9910
    rv_idx = np.flatnonzero(has_review)
    # Detractors write comments far more often than promoters.
    comment_p = np.where(score[rv_idx] <= 2, 0.72,
                np.where(score[rv_idx] == 3, 0.46, 0.29))
    wrote = RNG.random(len(rv_idx)) < comment_p
    created = orders["order_delivered_customer_date"].values[rv_idx]
    created = np.where(pd.isna(created),
                       orders["order_estimated_delivery_date"].values[rv_idx],
                       created)
    created = pd.to_datetime(created) + pd.to_timedelta(
        RNG.integers(0, 3, len(rv_idx)), unit="D")
    reviews = pd.DataFrame({
        "review_id": hexid(len(rv_idx)),
        "order_id": order_ids[rv_idx],
        "review_score": score[rv_idx],
        "review_comment_title": None,
        "review_comment_message": np.where(wrote, "comentario do cliente", None),
        "review_creation_date": created,
        "review_answer_timestamp": created + pd.to_timedelta(
            RNG.gamma(1.4, 1.6, len(rv_idx)), unit="D"),
    })

    # ---------- satisfaction filter on repeat purchase ----------
    # Now that scores exist, break the repeat links whose first order went badly.
    # A customer who was let down mostly does not come back; one who was not
    # mostly still does not, but far less rarely. Retention probability by first
    # review is set to roughly match the real dataset's 2.3x spread between
    # 5-star and 1-star first-time buyers.
    keep_p = {1: 0.42, 2: 0.50, 3: 0.70, 4: 0.88, 5: 1.00}
    for j in second_idx:
        i = np.flatnonzero(owner == owner[j])
        if len(i) < 2:
            continue
        first = i.min()
        if first == j:
            continue
        if RNG.random() > keep_p[int(score[first])]:
            owner[j] = N_ORDERS + j          # detach into a person of their own

    # Compact the person ids and emit the customer table.
    uniq, owner_compact = np.unique(owner, return_inverse=True)
    people = hexid(len(uniq))
    customers = pd.DataFrame({
        "customer_id": cust_ids,
        "customer_unique_id": people[owner_compact],
        "customer_zip_code_prefix": RNG.integers(1000, 99999, N_ORDERS),
        "customer_city": ["city_" + s.lower() for s in cust_state],
        "customer_state": cust_state,
    })

    # ---------- geolocation ----------
    ngeo = 60_000
    gstate = pick(st_names, cust_p, ngeo)
    geo = pd.DataFrame({
        "geolocation_zip_code_prefix": RNG.integers(1000, 99999, ngeo),
        "geolocation_lat": RNG.uniform(-33.7, 4.5, ngeo).round(6),
        "geolocation_lng": RNG.uniform(-73.9, -34.8, ngeo).round(6),
        "geolocation_city": ["city_" + s.lower() for s in gstate],
        "geolocation_state": gstate,
    })

    translation = pd.DataFrame({
        "product_category_name": list(CATEGORY_EN),
        "product_category_name_english": list(CATEGORY_EN.values()),
    })

    files = {
        "olist_orders_dataset.csv": orders,
        "olist_order_items_dataset.csv": order_items,
        "olist_order_payments_dataset.csv": payments,
        "olist_order_reviews_dataset.csv": reviews,
        "olist_products_dataset.csv": products,
        "olist_customers_dataset.csv": customers,
        "olist_sellers_dataset.csv": sellers,
        "olist_geolocation_dataset.csv": geo,
        "product_category_name_translation.csv": translation,
    }
    for name, df in files.items():
        df.to_csv(out / name, index=False)
        print(f"  wrote {name:<44} {len(df):>8,} rows")
    print(f"\nSample dataset written to {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/sample")
    build(Path(ap.parse_args().out))
