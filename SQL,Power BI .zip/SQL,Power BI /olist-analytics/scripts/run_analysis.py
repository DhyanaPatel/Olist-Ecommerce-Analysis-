"""
run_analysis.py — execute the analysis SQL and publish the results.

Usage:
    python scripts/run_analysis.py [--db olist.duckdb] [--out output]

Runs every file in sql/03_analysis in name order, writes each result to
output/tables/<name>.csv, and renders the four-page dashboard by injecting the
combined result set into scripts/dashboard_template.html.

The dashboard reads only from this JSON. No figure is typed by hand anywhere in
the HTML, so the report cannot drift away from the queries.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
ANALYSIS_DIR = ROOT / "sql" / "03_analysis"
TEMPLATE = Path(__file__).resolve().parent / "dashboard_template.html"


def clean(value):
    """JSON-safe scalar: NaN/inf become None, numpy types become Python types."""
    if value is None:
        return None
    if isinstance(value, float):
        return None if math.isnan(value) or math.isinf(value) else value
    if hasattr(value, "item"):
        try:
            value = value.item()
        except (ValueError, AttributeError):
            return str(value)
        return clean(value)
    if isinstance(value, (int, str, bool)):
        return value
    return str(value)


def run_all(con: duckdb.DuckDBPyConnection, tables_dir: Path) -> dict:
    tables_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, list[dict]] = {}

    for path in sorted(ANALYSIS_DIR.glob("*.sql")):
        name = path.stem
        df = con.execute(path.read_text()).df()
        df.to_csv(tables_dir / f"{name}.csv", index=False)
        results[name] = [
            {k: clean(v) for k, v in row.items()}
            for row in df.to_dict(orient="records")
        ]
        print(f"  {name:<34} {len(df):>4} rows -> {name}.csv")

    return results


def render_dashboard(results: dict, out_html: Path) -> None:
    if not TEMPLATE.exists():
        raise SystemExit(f"Missing dashboard template: {TEMPLATE}")
    html = TEMPLATE.read_text()
    payload = json.dumps(results, separators=(",", ":"))
    if "__DATA__" not in html:
        raise SystemExit("Template has no __DATA__ placeholder")
    out_html.parent.mkdir(parents=True, exist_ok=True)
    out_html.write_text(html.replace("__DATA__", payload))
    size_kb = out_html.stat().st_size / 1024
    print(f"\n  dashboard -> {out_html}  ({size_kb:,.0f} KB)")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=str(ROOT / "olist.duckdb"))
    ap.add_argument("--out", default=str(ROOT / "output"))
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        raise SystemExit(f"No database at {db}. Run scripts/build_db.py first.")

    out = Path(args.out)
    con = duckdb.connect(str(db), read_only=True)
    print("Running analysis queries")
    results = run_all(con, out / "tables")
    con.close()

    render_dashboard(results, out / "dashboard" / "index.html")


if __name__ == "__main__":
    main()
