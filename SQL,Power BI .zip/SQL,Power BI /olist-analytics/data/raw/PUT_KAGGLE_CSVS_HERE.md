# Drop the Kaggle CSVs here

Download **Brazilian E-Commerce Public Dataset by Olist** from
https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
and unzip the nine files into this folder:

    olist_customers_dataset.csv
    olist_geolocation_dataset.csv
    olist_order_items_dataset.csv
    olist_order_payments_dataset.csv
    olist_order_reviews_dataset.csv
    olist_orders_dataset.csv
    olist_products_dataset.csv
    olist_sellers_dataset.csv
    product_category_name_translation.csv

Then run:

    python scripts/build_db.py
    python scripts/run_analysis.py

`build_db.py` will tell you exactly which files are missing if any are.

Until then, the project runs on the generated sample in `data/sample/`, which has
the same schema and is calibrated to the real dataset's aggregates.
